import { system, world } from "@minecraft/server";
import { ActionFormData } from "@minecraft/server-ui";

const DOLL_MAP = {
    "keepsmiling:jester_doll": { item: "keepsmiling:jester_doll_spawn_egg", sound: "keepsmiling:jester_doll" },
    "keepsmiling:anderdingus_doll": { item: "keepsmiling:anderdingus_doll_spawn_egg", sound: "keepsmiling:mynameis_anderdingus" },
    "keepsmiling:smiler_doll": { item: "keepsmiling:smiler_doll_spawn_egg", sound: "keepsmiling:smiler_doll" },
    "keepsmiling:bipedal_doll": { item: "keepsmiling:bipedal_doll_spawn_egg", sound: "keepsmiling:bipedal_doll" },
    "keepsmiling:tormentor_doll": { item: "keepsmiling:tormentor_doll_spawn_egg", sound: "keepsmiling:tormentor_doll" }
};

const DOLL_IDS = Object.keys(DOLL_MAP);
const soundCooldowns = new Map();

// --- 1. UI SELEKSI BONEKA (DICEK SETIAP MASUK WORLD) ---
system.runInterval(() => {
    for (const player of world.getAllPlayers()) {
        if (!player.hasTag("has_chosen_doll") && !player.hasTag("opening_ui")) {
            showDollSelectionUI(player);
        }
    }
}, 40);

function showDollSelectionUI(player) {
    player.addTag("opening_ui");
    
    const form = new ActionFormData()
        .title("Choose your doll")
        .body("Choose your starting doll:")
        .button("Jester Doll")
        .button("My Name Is Anderdingus")
        .button("Smiler Doll")
        .button("Bipedal Doll")
        .button("Tormentor Doll");

    form.show(player).then((response) => {
        player.removeTag("opening_ui");

        if (response.canceled) {
            return;
        }

        player.addTag("has_chosen_doll");
        const dollKeys = Object.keys(DOLL_MAP);
        const selectedDoll = dollKeys[response.selection];
        const giveItem = DOLL_MAP[selectedDoll].item;

        player.runCommandAsync(`give @s ${giveItem} 1`);
    }).catch(() => {
        player.removeTag("opening_ui");
    });
}

// --- 2. SISTEM SELALU MENATAP PLAYER ---
system.runInterval(() => {
    const overworld = world.getDimension("overworld");

    for (const typeId of DOLL_IDS) {
        const dolls = Array.from(overworld.getEntities({ type: typeId }));

        for (const doll of dolls) {
            if (!doll.isValid()) continue;

            const players = Array.from(overworld.getPlayers({ location: doll.location, maxDistance: 16 }));
            if (players.length > 0) {
                const target = players[0];
                const dx = target.location.x - doll.location.x;
                const dz = target.location.z - doll.location.z;
                const yaw = (Math.atan2(-dx, dz) * 180) / Math.PI;

                try {
                    doll.teleport(doll.location, { rotation: { x: 0, y: yaw } });
                } catch (e) {}
            }
        }
    }
}, 1);

// --- 3. INTERAKSI: JONGKOK (TAKE DOLL) VS BERDIRI (TALK + SOUND) ---
world.beforeEvents.playerInteractWithEntity.subscribe((event) => {
    const { target, player } = event;

    if (DOLL_MAP[target.typeId]) {
        // A. JIKA PLAYER JONGKOK -> AMBIL BONEKA (DESPAWN & GIVE ITEM)
        if (player.isSneaking) {
            const itemToGive = DOLL_MAP[target.typeId].item;
            
            // Berikan item ke player dan hapus entitas boneka dari tanah
            system.run(() => {
                player.runCommandAsync(`give @s ${itemToGive} 1`);
                target.remove();
            });
            return;
        }

        // B. JIKA PLAYER BERDIRI -> INTERAKSI TALK DENGAN COOLDOWN 5 DETIK
        const now = Date.now();
        const lastUsed = soundCooldowns.get(target.id) || 0;

        if (now - lastUsed < 5000) {
            event.cancel = true;
            return;
        }

        soundCooldowns.set(target.id, now);
        const soundToPlay = DOLL_MAP[target.typeId].sound;

        player.runCommandAsync(`playsound ${soundToPlay} @a ~ ~ ~`);
    }
});
