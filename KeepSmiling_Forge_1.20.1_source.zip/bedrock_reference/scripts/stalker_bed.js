import { world, system } from "@minecraft/server";

const STALKER_ID = "keepsmiling:stalker_bed";
const PLAYER_SLEEP_TRACKER = new Map();

function getCurrentDay() {
    return Math.floor(world.getDay());
}

// 1. Loop Utama Deteksi Player Tidur & Cooldown 2 Hari
system.runInterval(() => {
    const overworld = world.getDimension("overworld");
    const currentDay = getCurrentDay();

    for (const player of world.getPlayers()) {
        const isSleeping = player.isSleeping;
        const wasSleeping = PLAYER_SLEEP_TRACKER.get(player.id) || false;

        // Player baru saja berbaring tidur
        if (isSleeping && !wasSleeping) {
            PLAYER_SLEEP_TRACKER.set(player.id, true);

            const lastSpawnDay = player.getDynamicProperty("stalker_last_spawn_day") ?? -999;

            // Memastikan muncul di hari ke-2+ dan berselang minimal 2 hari sekali
            if (currentDay >= 2 && (currentDay - lastSpawnDay) >= 2) {
                spawnStalkerInFrontOfBed(player, overworld);
                player.setDynamicProperty("stalker_last_spawn_day", currentDay);
            }
        } 
        // Player bangun dari kasur
        else if (!isSleeping && wasSleeping) {
            PLAYER_SLEEP_TRACKER.set(player.id, false);
            despawnStalkersAndPlaySound(player, overworld);
        }
    }
}, 5);

// HANDLER SPAWN MANUAL (EGG / SUMMON) -> LANGSUNG DESPAWN JIKA PLAYER TIDAK TIDUR
world.afterEvents.entitySpawn.subscribe((event) => {
    const entity = event.entity;
    if (entity.typeId === STALKER_ID) {
        system.runTimeout(() => {
            const overworld = world.getDimension("overworld");
            const players = Array.from(world.getPlayers());
            
            // Cari player terdekat yang sedang tidur
            const sleepingPlayer = players.find(p => p.isSleeping && Math.hypot(p.location.x - entity.location.x, p.location.z - entity.location.z) < 6);

            if (!sleepingPlayer) {
                // Jika tidak ada player tidur di dekatnya, langsung despawn begitu saja
                try { entity.remove(); } catch (e) {}
            }
        }, 1);
    }
});

// 2. Kalkulasi Vektor Presisi Sisi Kasur (Ujung Kiri -> Kanan, Ujung Kanan -> Kiri)
function spawnStalkerInFrontOfBed(player, dimension) {
    try {
        const pLoc = player.location;
        const playerYaw = player.getRotation().y; // Arah pandang pemain saat tidur

        const rad = (playerYaw * Math.PI) / 180;
        
        // Vektor Depan
        const dirX = -Math.sin(rad);
        const dirZ = Math.cos(rad);

        // Vektor Samping Kanan (Perpendicular Right)
        const rightX = -dirZ;
        const rightZ = dirX;

        // Vektor Samping Kiri (Perpendicular Left)
        const leftX = dirZ;
        const leftZ = -dirX;

        // Cek halangan dinding/blok di sebelah kiri kasur
        const checkLeftX = Math.floor(pLoc.x + leftX * 1.5);
        const checkLeftZ = Math.floor(pLoc.z + leftZ * 1.5);
        const bLeft = dimension.getBlock({ x: checkLeftX, y: Math.floor(pLoc.y), z: checkLeftZ });

        // Cek halangan dinding/blok di sebelah kanan kasur
        const checkRightX = Math.floor(pLoc.x + rightX * 1.5);
        const checkRightZ = Math.floor(pLoc.z + rightZ * 1.5);
        const bRight = dimension.getBlock({ x: checkRightX, y: Math.floor(pLoc.y), z: checkRightZ });

        const isLeftBlocked = bLeft && !bLeft.isAir;
        const isRightBlocked = bRight && !bRight.isAir;

        let spawnOffsetX = 0;
        let spawnOffsetZ = 0;

        // Logika penentuan posisi berdasarkan ujung kasur:
        // Jika kasur di ujung kiri (kiri terhalang), spawn di sebelah kanan
        if (isLeftBlocked && !isRightBlocked) {
            spawnOffsetX = rightX * 1.8;
            spawnOffsetZ = rightZ * 1.8;
        } 
        // Jika kasur di ujung kanan (kanan terhalang), spawn di sebelah kiri
        else if (isRightBlocked && !isLeftBlocked) {
            spawnOffsetX = leftX * 1.8;
            spawnOffsetZ = leftZ * 1.8;
        } 
        // Jika tidak ada halangan khusus, gunakan offset default (depan agak ke samping kanan)
        else {
            spawnOffsetX = dirX * 1.5 + rightX * 1.0;
            spawnOffsetZ = dirZ * 1.5 + rightZ * 1.0;
        }

        const targetX = pLoc.x + spawnOffsetX;
        const targetZ = pLoc.z + spawnOffsetZ;
        const targetY = pLoc.y;

        // Spawn Stalker Bed
        const stalker = dimension.spawnEntity(STALKER_ID, { x: targetX, y: targetY, z: targetZ });
        stalker.setDynamicProperty("ownerPlayerId", player.id);

        // Hitung sudut rotasi agar entitas tetap menatap lurus ke arah muka pemain
        const dx = pLoc.x - targetX;
        const dz = pLoc.z - targetZ;
        const stalkerYaw = (Math.atan2(dz, dx) * 180) / Math.PI - 90;

        stalker.setRotation({ x: 0, y: stalkerYaw });

    } catch (e) {
        console.warn("Gagal merender Stalker Bed: " + e);
    }
}

// 3. Despawn & Efek Suara 'stalker_bed_bye' Saat Player Bangun
function despawnStalkersAndPlaySound(player, dimension) {
    const stalkers = Array.from(dimension.getEntities({ type: STALKER_ID }));
    let hasDespawned = false;

    for (const stalker of stalkers) {
        const ownerId = stalker.getDynamicProperty("ownerPlayerId");
        if (ownerId === player.id || Math.hypot(stalker.location.x - player.location.x, stalker.location.z - player.location.z) < 6) {
            stalker.remove();
            hasDespawned = true;
        }
    }

    if (hasDespawned) {
        try {
            player.playSound("keepsmiling:stalker_bed_bye");
        } catch (e) {}
    }
}
