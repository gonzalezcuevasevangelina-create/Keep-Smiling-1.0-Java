package com.keepsmiling;

import net.minecraftforge.fml.common.Mod;

@Mod(KeepSmiling.MODID)
public class KeepSmiling {
    public static final String MODID = "keepsmiling";

    public KeepSmiling() {
        // Punto de entrada Forge. El registro de entidades, modelos, IA y sonidos
        // debe implementarse aquí/en clases registradoras durante el port real.
    }
}
