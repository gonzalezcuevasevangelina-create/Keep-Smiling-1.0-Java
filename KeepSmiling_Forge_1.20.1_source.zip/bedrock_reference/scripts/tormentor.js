import { world, system, GameMode } from "@minecraft/server";

const TORMENTOR_ID = "keepsmiling:tormentor";
const UNBREAKABLE = [
    "minecraft:bedrock", 
    "minecraft:reinforced_deepslate", 
    "minecraft:barrier", 
    "minecraft:command_block"
];
const tormentorStates = new Map();

let spawnCooldown = 0;
let lastWorldDaySpawned = -1;

function isFlower(typeId) {
    if (!typeId) return false;
    const id = typeId.toLowerCase();
    return id.includes("flower") || id.includes("rose") || id.includes("dandelion") || 
           id.includes("poppy") || id.includes("orchid") || id.includes("allium") || 
           id.includes("tulip") || id.includes("daisy") || id.includes("cornflower") || 
           id.includes("lily") || id.includes("sunflower") || id.includes("lilac") || 
           id.includes("peony") || id.includes("pitcher") || id.includes("torchflower");
}

function isPassableGrass(typeId) {
    if (!typeId) return false;
    const id = typeId.toLowerCase();
    return id.includes("short_grass") || id.includes("tall_grass") || 
          (id.includes("grass") && !id.includes("block") && !id.includes("path"));
}

function isBlockUnbreakable(typeId) {
    if (!typeId) return false;
    const id = typeId.toLowerCase();
    return UNBREAKABLE.some(unb => id === unb || id.includes("bedrock") || id.includes("reinforced_deepslate"));
}

function isBlockBlockingLOS(dim, headLoc, tormentorLoc, distance) {
    try {
        const dx = tormentorLoc.x - headLoc.x;
        const dy = (tormentorLoc.y + 1.8) - headLoc.y;
        const dz = tormentorLoc.z - headLoc.z;

        const ray = dim.getBlockFromRay(headLoc, { x: dx, y: dy, z: dz }, {
            maxDistance: distance,
            includePassableBlocks: false,
            includeLiquidBlocks: false
        });

        return ray && ray.block && !ray.block.isAir;
    } catch (e) {
        return false;
    }
}

function destroyObstacleBlock(dim, x, y, z) {
    try {
        const block = dim.getBlock({ x: Math.floor(x), y: Math.floor(y), z: Math.floor(z) });
        if (block && !block.isAir && !isBlockUnbreakable(block.typeId)) {
            block.setType("minecraft:air");
        }
    } catch (e) {}
}

// ROTASI PITCH & YAW DINAMIS (REBAH SELALU MENGHADAP PLAYER)
function faceTarget(tormentor, player) {
    try {
        const pHead = player.getHeadLocation();
        const sLoc = tormentor.location;

        const dx = pHead.x - sLoc.x;
        const dy = pHead.y - (sLoc.y + 1.2);
        const dz = pHead.z - sLoc.z;

        const distXZ = Math.hypot(dx, dz);
        const yaw = (Math.atan2(dz, dx) * 180) / Math.PI - 90;

        let pitch = 0;
        if (distXZ < 0.01) {
            pitch = dy > 0 ? 89.9 : -89.9;
        } else {
            pitch = (Math.atan2(dy, distXZ) * 180) / Math.PI;
        }

        pitch = Math.max(-89.9, Math.min(89.9, pitch));
        tormentor.setRotation({ x: pitch, y: yaw });
    } catch (e) {}
}

// PERGERAKAN TELEPORTASI REALISTIS (MENIKUNG & MENGHANCURKAN BLOK SESUAI SKRIP STALKER)
function moveChaser(tormentor, player, speed) {
    try {
        const dim = tormentor.dimension;
        const sLoc = tormentor.location;
        const pLoc = player.location;

        const dx = pLoc.x - sLoc.x;
        const dz = pLoc.z - sLoc.z;
        const dist = Math.hypot(dx, dz);

        if (dist > 0.8) {
            const vx = (dx / dist) * speed;
            const vz = (dz / dist) * speed;

            let targetX = sLoc.x + vx;
            let targetZ = sLoc.z + vz;

            const frontX = Math.floor(targetX);
            const frontZ = Math.floor(targetZ);
            const currentFootY = Math.floor(sLoc.y);

            const currentBlockAtFoot = dim.getBlock({ x: frontX, y: currentFootY, z: frontZ });
            if (currentBlockAtFoot && isFlower(currentBlockAtFoot.typeId)) {
                dim.runCommandAsync(`setblock ${frontX} ${currentFootY} ${frontZ} air replace`);
            }

            let wallHeight = 0;
            let isUnbreakableObstacle = false;

            for (let checkY = currentFootY; checkY <= currentFootY + 10; checkY++) {
                const b = dim.getBlock({ x: frontX, y: checkY, z: frontZ });
                if (b && !b.isAir && !b.isLiquid) {
                    if (isPassableGrass(b.typeId)) continue;
                    if (isFlower(b.typeId)) {
                        dim.runCommandAsync(`setblock ${frontX} ${checkY} ${frontZ} air replace`);
                        continue;
                    }
                    if (isBlockUnbreakable(b.typeId)) {
                        isUnbreakableObstacle = true;
                    }
                    wallHeight++;
                } else {
                    break;
                }
            }

            let newY = sLoc.y;

            if (isUnbreakableObstacle) {
                const sideLeftX = Math.floor(sLoc.x - vz * 2);
                const sideLeftZ = Math.floor(sLoc.z + vx * 2);
                const blockLeft = dim.getBlock({ x: sideLeftX, y: currentFootY, z: sideLeftZ });

                if (!blockLeft || blockLeft.isAir || !isBlockUnbreakable(blockLeft.typeId)) {
                    targetX = sLoc.x - vz * speed;
                    targetZ = sLoc.z + vx * speed;
                } else {
                    targetX = sLoc.x + vz * speed;
                    targetZ = sLoc.z - vx * speed;
                }
                newY = currentFootY;
            } else if (wallHeight === 1) {
                newY = currentFootY + 1;
            } else if (wallHeight >= 2) {
                for (let offsetY = 0; offsetY < wallHeight + 2; offsetY++) {
                    const checkY = currentFootY + offsetY;
                    try {
                        destroyObstacleBlock(dim, frontX, checkY, frontZ);
                    } catch (e) {}
                }
                newY = currentFootY;
            } else {
                let groundY = currentFootY;
                for (let checkY = currentFootY + 1; checkY >= currentFootY - 5; checkY--) {
                    const blockBelow = dim.getBlock({ x: frontX, y: checkY, z: frontZ });
                    if (blockBelow && !blockBelow.isAir && !blockBelow.isLiquid && !isPassableGrass(blockBelow.typeId)) {
                        groundY = checkY + 1;
                        break;
                    }
                }
                newY = groundY;
            }

            tormentor.teleport({ x: targetX, y: newY, z: targetZ }, { dimension: dim });
        }
        faceTarget(tormentor, player);
    } catch (e) {}
}

// PELUANG SPAWN TORMENTOR (MAKSIMAL 1 KALI PER HARI MINECRAFT)
system.runInterval(() => {
    const players = Array.from(world.getPlayers());
    if (players.length === 0) return;

    const overworld = world.getDimension("overworld");
    const existingTormentors = Array.from(overworld.getEntities({ type: TORMENTOR_ID }));

    if (existingTormentors.length >= 1) return;

    spawnCooldown++;
    if (spawnCooldown < 100) return;
    spawnCooldown = 0;

    const timeOfDay = world.getTimeOfDay();
    const currentDay = Math.floor(world.getAbsoluteTime() / 24000);

    if (currentDay <= lastWorldDaySpawned) {
        return;
    }

    const isMorning = timeOfDay >= 0 && timeOfDay < 3000;
    const isDay = timeOfDay >= 3000 && timeOfDay < 9000;
    const isAfternoon = timeOfDay >= 9000 && timeOfDay < 12000;
    const isSunset = timeOfDay >= 12000 && timeOfDay < 13000;
    const isNight = timeOfDay >= 13000 && timeOfDay <= 23000;

    for (const player of players) {
        if (player.getGameMode() !== GameMode.survival && player.getGameMode() !== GameMode.adventure) {
            continue;
        }

        const pLoc = player.location;
        const dim = player.dimension;
        const headBlock = dim.getBlock({ x: Math.floor(pLoc.x), y: Math.floor(pLoc.y + 1), z: Math.floor(pLoc.z) });
        const inCave = pLoc.y < 50 || (headBlock && headBlock.getSkyLightLevel && headBlock.getSkyLightLevel() === 0);

        let canSpawn = false;

        if (inCave) {
            if (Math.random() < 0.70) canSpawn = true;
        } else {
            if (isDay && Math.random() < 0.05) canSpawn = true;
            if (isMorning && Math.random() < 0.05) canSpawn = true;
            if (isAfternoon && Math.random() < 0.05) canSpawn = true;
            if ((isSunset || isNight) && Math.random() < 0.50) canSpawn = true;
        }

        if (!canSpawn) continue;

        const angle = Math.random() * Math.PI * 2;
        const distance = 25 + Math.random() * 15;
        const spawnX = Math.floor(pLoc.x + Math.cos(angle) * distance);
        const spawnZ = Math.floor(pLoc.z + Math.sin(angle) * distance);
        let spawnY = Math.floor(pLoc.y);
        let validPos = null;

        for (let yOffset = 5; yOffset >= -5; yOffset--) {
            const checkY = spawnY + yOffset;
            const blockBelow = dim.getBlock({ x: spawnX, y: checkY - 1, z: spawnZ });
            const blockCurrent = dim.getBlock({ x: spawnX, y: checkY, z: spawnZ });
            const blockAbove = dim.getBlock({ x: spawnX, y: checkY + 1, z: spawnZ });

            if (blockBelow && !blockBelow.isAir && blockBelow.isSolid 
                && blockCurrent && blockCurrent.isAir 
                && blockAbove && blockAbove.isAir) {
                validPos = { x: spawnX + 0.5, y: checkY, z: spawnZ + 0.5 };
                break;
            }
        }

        if (validPos) {
            try {
                const tormentor = dim.spawnEntity(TORMENTOR_ID, validPos);
                
                tormentorStates.set(tormentor.id, {
                    state: "WAIT",
                    waitTimer: 0,
                    musicTimer: 0,
                    warnTimer: 0,
                    chaseTimer: 0,
                    chaseSoundTimer: 0,
                    targetPlayer: player
                });

                player.runCommandAsync("playsound keepsmiling:tormentor_wait @s");
                lastWorldDaySpawned = currentDay;
                break;
            } catch (e) {}
        }
    }
}, 20);

// SPAWN MANUAL VIA EGG / SUMMON
world.afterEvents.entitySpawn.subscribe((event) => {
    const entity = event.entity;
    if (entity.typeId === TORMENTOR_ID) {
        system.runTimeout(() => {
            if (!tormentorStates.has(entity.id)) {
                const players = Array.from(world.getPlayers());
                if (players.length > 0) {
                    const player = players[0];
                    tormentorStates.set(entity.id, {
                        state: "WAIT",
                        waitTimer: 0,
                        musicTimer: 0,
                        warnTimer: 0,
                        chaseTimer: 0,
                        chaseSoundTimer: 0,
                        targetPlayer: player
                    });
                    player.runCommandAsync("playsound keepsmiling:tormentor_wait @s");
                }
            }
        }, 2);
    }
});

// ROTASI & PERGERAKAN CHASE REALTIME (EVERY 1 TICK)
system.runInterval(() => {
    const overworld = world.getDimension("overworld");
    const players = Array.from(world.getPlayers());

    if (players.length === 0) return;

    const tormentors = Array.from(overworld.getEntities({ type: TORMENTOR_ID }));

    for (const tormentor of tormentors) {
    if (!tormentor.isValid()) continue;

        const data = tormentorStates.get(tormentor.id);

        let targetPlayer = null;
        let minDist = Infinity;
        for (const player of players) {
            const dist = Math.hypot(player.location.x - tormentor.location.x, player.location.z - tormentor.location.z);
            if (dist < minDist) {
                minDist = dist;
                targetPlayer = player;
            }
        }

        if (targetPlayer) {
            faceTarget(tormentor, targetPlayer);

            // Jika dalam kondisi CHASE, eksekusi pergerakan teleport 1-tick dengan speed 1.00
            if (data && data.state === "CHASE") {
                moveChaser(tormentor, targetPlayer, 1.00);
            }
        }
    }
}, 1);

// LOGIKA AI DAN STATE MACHINE
system.runInterval(() => {
    const overworld = world.getDimension("overworld");
    const tormentors = Array.from(overworld.getEntities({ type: TORMENTOR_ID }));

    for (const tormentor of tormentors) {
        if (!tormentor.isValid()) continue;

        const data = tormentorStates.get(tormentor.id);
        if (!data) continue;

        const player = data.targetPlayer;
        if (!player || !player.isValid()) {
            tormentor.remove();
            tormentorStates.delete(tormentor.id);
            continue;
        }

        const tLoc = tormentor.location;
        const pLoc = player.location;
        const pHead = player.getHeadLocation();
        const dist = Math.hypot(pLoc.x - tLoc.x, pLoc.z - tLoc.z);

        if (data.state === "WAIT") {
            if (dist > 60) {
                data.waitTimer += 2;
                if (data.waitTimer >= 120) { // Berulang setiap 6 detik jika berjarak >60 block
                    player.runCommandAsync("playsound keepsmiling:tormentor_wait @s");
                    data.waitTimer = 0;
                }
            } else {
                const isBlocked = isBlockBlockingLOS(overworld, pHead, tLoc, dist);

                if (!isBlocked) {
                    data.state = "MUSIC";
                    data.musicTimer = 0;
                    player.runCommandAsync("playsound keepsmiling:tormentor_music @s");
                }
            }
        } else if (data.state === "MUSIC") {
            data.musicTimer += 2;

            if (data.musicTimer >= 60) { // 3 Detik setelah musik diputar
                data.state = "WARN";
                data.warnTimer = 0;

                // Mengubah varian ke 1 (tekstur tormentor_run.png)
                tormentor.triggerEvent("event:start_chase");

                player.runCommandAsync("playsound keepsmiling:tormentor_warn @s");
                player.runCommandAsync("playsound keepsmiling:tormentor_crack @s");
            }
        } else if (data.state === "WARN") {
            data.warnTimer += 2;

            // Berhenti diam 1 detik (20 ticks) saat suara warn/crack diputar
            if (data.warnTimer >= 20) {
                data.state = "CHASE";
                data.chaseTimer = 0;
                data.chaseSoundTimer = 0;

                // Memulai animasi chase di client entity
                tormentor.addTag("is_chasing");

                player.runCommandAsync("playsound keepsmiling:tormentor_chase @s");
            }
        } else if (data.state === "CHASE") {
            data.chaseTimer += 2;
            data.chaseSoundTimer += 2;

            try {
                player.addEffect("darkness", 40, { amplifier: 0, showParticles: false });
            } catch (e) {}

            if (data.chaseSoundTimer >= 120) { // Suara chase diulang setiap 6 detik
                player.runCommandAsync("playsound keepsmiling:tormentor_chase @s");
                data.chaseSoundTimer = 0;
            }

            // Despawn di detik ke-48 (960 ticks)
            if (data.chaseTimer >= 960) {
                try {
                    player.runCommandAsync("stopsound @s keepsmiling:tormentor_music");
                    player.runCommandAsync("stopsound @s keepsmiling:tormentor_chase");
                    player.removeEffect("darkness");
                } catch (e) {}

                tormentorStates.delete(tormentor.id);
                try { tormentor.remove(); } catch (e) {}
                continue;
            }
        }
    }
}, 2);

// REMOVE INTEGRAL SAAT PLAYER MATI
world.afterEvents.entityDie.subscribe((event) => {
    if (event.deadEntity.typeId === "minecraft:player") {
        const player = event.deadEntity;
        try {
            player.runCommandAsync("stopsound @s keepsmiling:tormentor_wait");
            player.runCommandAsync("stopsound @s keepsmiling:tormentor_music");
            player.runCommandAsync("stopsound @s keepsmiling:tormentor_warn");
            player.runCommandAsync("stopsound @s keepsmiling:tormentor_crack");
            player.runCommandAsync("stopsound @s keepsmiling:tormentor_chase");
            player.removeEffect("darkness");
        } catch (e) {}

        const overworld = world.getDimension("overworld");
        const tormentors = Array.from(overworld.getEntities({ type: TORMENTOR_ID }));
        for (const tormentor of tormentors) {
            tormentor.remove();
            tormentorStates.delete(tormentor.id);
        }
    }
});
