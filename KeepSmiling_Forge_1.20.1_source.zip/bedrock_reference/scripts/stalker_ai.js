import { system, world, GameMode } from "@minecraft/server";

const STALKER_ID = "keepsmiling:stalker";
const stalkerData = new Map();
const playerSpawnCooldowns = new Map();

const UNBREAKABLE = [
    "minecraft:bedrock", 
    "minecraft:reinforced_deepslate", 
    "minecraft:barrier", 
    "minecraft:command_block",
    "minecraft:repeating_command_block",
    "minecraft:chain_command_block"
];

const STALKER_PROBE_INTERVAL_TICKS = 40;
const STALKER_CAVE_INTERVAL_TICKS = 600;
const STALKER_DAY_INTERVAL_TICKS = 2400;
const STALKER_NIGHT_INTERVAL_TICKS = 1200;
const EQUAL_AGGRESSIVE_SPAWN_CHANCE = 0.35;

function gameTime() {
    return world.getAbsoluteTime();
}

function isDay() {
    const timeOfDay = world.getTimeOfDay();
    return timeOfDay >= 0 && timeOfDay < 12000;
}

function hasActive(dimension, typeId) {
    try {
        return Array.from(dimension.getEntities({ type: typeId })).length > 0;
    } catch (e) {
        return false;
    }
}

function duePlayer(player, key, cooldownTicks) {
    const current = gameTime();
    const lastKey = `${player.id}_${key}`;
    const lastTick = playerSpawnCooldowns.get(lastKey) || 0;
    if (current - lastTick >= cooldownTicks) {
        playerSpawnCooldowns.set(lastKey, current);
        return true;
    }
    return false;
}

function isCave(dimension, location) {
    try {
        const headBlock = dimension.getBlock({ x: Math.floor(location.x), y: Math.floor(location.y + 1), z: Math.floor(location.z) });
        return location.y < 50 || (headBlock && headBlock.getSkyLightLevel && headBlock.getSkyLightLevel() === 0);
    } catch (e) {
        return false;
    }
}

function canSeeSky(dimension, location) {
    try {
        const headBlock = dimension.getBlock({ x: Math.floor(location.x), y: Math.floor(location.y + 1), z: Math.floor(location.z) });
        return headBlock && headBlock.getSkyLightLevel && headBlock.getSkyLightLevel() > 0;
    } catch (e) {
        return true;
    }
}

function findBehindPlayerSpot(dimension, player, minDist, maxDist) {
    try {
        const pLoc = player.location;
        const vDir = player.getViewDirection();
        const dist = minDist + Math.random() * (maxDist - minDist);
        
        const targetX = Math.floor(pLoc.x - vDir.x * dist);
        const targetZ = Math.floor(pLoc.z - vDir.z * dist);
        const spawnY = Math.floor(pLoc.y);

        for (let yOffset = 4; yOffset >= -4; yOffset--) {
            const checkY = spawnY + yOffset;
            const bBelow = dimension.getBlock({ x: targetX, y: checkY - 1, z: targetZ });
            const bCurr = dimension.getBlock({ x: targetX, y: checkY, z: targetZ });
            const bAbove = dimension.getBlock({ x: targetX, y: checkY + 1, z: targetZ });

            if (bBelow && !bBelow.isAir && bBelow.isSolid && bCurr && bCurr.isAir && bAbove && bAbove.isAir) {
                return { x: targetX + 0.5, y: checkY, z: targetZ + 0.5 };
            }
        }
        return null;
    } catch (e) {
        return null;
    }
}

function findSurfaceSpot(dimension, location, minDist, maxDist, skyCheck) {
    try {
        const angle = Math.random() * Math.PI * 2;
        const dist = minDist + Math.random() * (maxDist - minDist);
        const spawnX = Math.floor(location.x + Math.cos(angle) * dist);
        const spawnZ = Math.floor(location.z + Math.sin(angle) * dist);
        const spawnY = Math.floor(location.y);

        for (let yOffset = 5; yOffset >= -5; yOffset--) {
            const checkY = spawnY + yOffset;
            const bBelow = dimension.getBlock({ x: spawnX, y: checkY - 1, z: spawnZ });
            const bCurr = dimension.getBlock({ x: spawnX, y: checkY, z: spawnZ });
            const bAbove = dimension.getBlock({ x: spawnX, y: checkY + 1, z: spawnZ });

            if (bBelow && !bBelow.isAir && bBelow.isSolid && bCurr && bCurr.isAir && bAbove && bAbove.isAir) {
                return { x: spawnX + 0.5, y: checkY, z: spawnZ + 0.5 };
            }
        }
        return null;
    } catch (e) {
        return null;
    }
}

function maybeSpawnStalker(dimension, player) {
    if (!duePlayer(player, "stalker_probe", STALKER_PROBE_INTERVAL_TICKS)) return;
    if (hasActive(dimension, STALKER_ID)) return;

    const cave = isCave(dimension, player.location);
    const nature = canSeeSky(dimension, player.location);
    if (!cave && !nature) return;

    const interval = cave ? STALKER_CAVE_INTERVAL_TICKS : isDay() ? STALKER_DAY_INTERVAL_TICKS : STALKER_NIGHT_INTERVAL_TICKS;
    if (!duePlayer(player, "stalker", interval)) return;
    if (Math.random() > EQUAL_AGGRESSIVE_SPAWN_CHANCE) return;

    const pos = findBehindPlayerSpot(dimension, player, 12, 24) ?? findSurfaceSpot(dimension, player.location, 12, 26, 20);
    if (!pos) return;

    try {
        dimension.spawnEntity(STALKER_ID, pos);
    } catch (e) {}
}

function isFlower(typeId) {
    if (!typeId) return false;
    const id = typeId.toLowerCase();
    return id.includes("flower") || id.includes("rose") || id.includes("dandelion") || 
           id.includes("poppy") || id.includes("orchid") || id.includes("allium") || 
           id.includes("tulip") || id.includes("daisy") || id.includes("cornflower") || 
           id.includes("lily") || id.includes("sunflower") || id.includes("lilac") || 
           id.includes("peony") || id.includes("pitcher") || id.includes("torchflower");
}

function isPassableGrass(typeId) {
    if (!typeId) return false;
    const id = typeId.toLowerCase();
    return id.includes("short_grass") || id.includes("tall_grass") || 
          (id.includes("grass") && !id.includes("block") && !id.includes("path"));
}

function isBlockUnbreakable(typeId) {
    if (!typeId) return false;
    const id = typeId.toLowerCase();
    return UNBREAKABLE.some(unb => id === unb || id.includes("bedrock") || id.includes("reinforced_deepslate"));
}

function hasLineOfSight(player, stalker) {
    try {
        const headLoc = player.getHeadLocation();
        const sPos = stalker.location;
        sPos.y += 1.5;

        const rayResult = player.dimension.getBlockFromRay(headLoc, {
            x: sPos.x - headLoc.x,
            y: sPos.y - headLoc.y,
            z: sPos.z - headLoc.z
        }, { 
            maxDistance: Math.hypot(sPos.x - headLoc.x, sPos.y - headLoc.y, sPos.z - headLoc.z), 
            includePassableBlocks: false 
        });

        if (rayResult && rayResult.block) {
            const b = rayResult.block.typeId.toLowerCase();
            const isTransparent = b.includes("glass") || b.includes("pane") || b.includes("fence") || b.includes("trapdoor") || b.includes("iron_bars") || b.includes("door");
            if (!isTransparent) return false;
        }
        return true;
    } catch (e) {
        return true;
    }
}

function playGlobalSound(player, soundName, volume = 1.0, pitch = 1.0) {
    try {
        player.runCommandAsync(`playsound ${soundName} @s`);
    } catch (e) {
        try {
            player.dimension.playSound(soundName, player.location, { volume: volume, pitch: pitch });
        } catch (err) {}
    }
}

function updateStalkerLighting(stalker) {}

function faceTarget(stalker, player, isChasing = false) {
    try {
        const pHead = player.getHeadLocation();
        const pLoc = player.location;
        const sLoc = stalker.location;

        const dx = pHead.x - sLoc.x;
        const dy = pHead.y - (sLoc.y + 1.2);
        const dz = pHead.z - sLoc.z;

        const distXZ = Math.hypot(dx, dz);
        const yaw = (Math.atan2(dz, dx) * 180) / Math.PI - 90;

        let pitch = 0;
        if (distXZ < 0.01) {
            pitch = dy > 0 ? 89.9 : -89.9;
        } else {
            pitch = (Math.atan2(dy, distXZ) * 180) / Math.PI;
        }

        const yDiff = Math.abs(pLoc.y - sLoc.y);
        const isGroundLevel = yDiff <= 1.5;

        if (isChasing && isGroundLevel && distXZ < 6.5) {
            const leanOffset = Math.sin((6.5 - distXZ) / 6.5 * (Math.PI / 2)) * 22.0;
            pitch -= leanOffset;
        }

        pitch = Math.max(-89.9, Math.min(89.9, pitch));
        stalker.setRotation({ x: pitch, y: yaw });
    } catch (e) {}
}

function moveChaser(stalker, player, speed) {
    try {
        const dim = stalker.dimension;
        const sLoc = stalker.location;
        const pLoc = player.location;

        const dx = pLoc.x - sLoc.x;
        const dz = pLoc.z - sLoc.z;
        const dist = Math.hypot(dx, dz);

        if (dist > 0.8) {
            let vx = (dx / dist) * speed;
            let vz = (dz / dist) * speed;

            let targetX = sLoc.x + vx;
            let targetZ = sLoc.z + vz;

            const currentFootY = Math.floor(sLoc.y);

            const currentBlockAtFoot = dim.getBlock({ x: Math.floor(targetX), y: currentFootY, z: Math.floor(targetZ) });
            if (currentBlockAtFoot && isFlower(currentBlockAtFoot.typeId)) {
                dim.runCommandAsync(`setblock ${Math.floor(targetX)} ${currentFootY} ${Math.floor(targetZ)} air replace`);
            }

            let wallHeight = 0;
            let isUnbreakableObstacle = false;

            for (let checkY = currentFootY; checkY <= currentFootY + 10; checkY++) {
                const b = dim.getBlock({ x: Math.floor(targetX), y: checkY, z: Math.floor(targetZ) });
                if (b && !b.isAir) {
                    if (isPassableGrass(b.typeId)) continue;
                    if (isFlower(b.typeId)) {
                        dim.runCommandAsync(`setblock ${Math.floor(targetX)} ${checkY} ${Math.floor(targetZ)} air replace`);
                        continue;
                    }
                    if (isBlockUnbreakable(b.typeId)) {
                        isUnbreakableObstacle = true;
                    }
                    wallHeight++;
                } else {
                    break;
                }
            }

            let newY = sLoc.y;

            if (isUnbreakableObstacle) {
                const sideLeftX = Math.floor(sLoc.x - vz * 2);
                const sideLeftZ = Math.floor(sLoc.z + vx * 2);
                const blockLeft = dim.getBlock({ x: sideLeftX, y: currentFootY, z: sideLeftZ });

                if (!blockLeft || blockLeft.isAir || !isBlockUnbreakable(blockLeft.typeId)) {
                    targetX = sLoc.x - vz * speed;
                    targetZ = sLoc.z + vx * speed;
                } else {
                    targetX = sLoc.x + vz * speed;
                    targetZ = sLoc.z - vx * speed;
                }
                newY = currentFootY;
            } else if (wallHeight === 1) {
                newY = currentFootY + 1;
            } else if (wallHeight >= 2) {
                for (let offsetY = 0; offsetY < wallHeight + 2; offsetY++) {
                    const checkY = currentFootY + offsetY;
                    try {
                        const blockToDestroy = dim.getBlock({ x: Math.floor(targetX), y: checkY, z: Math.floor(targetZ) });
                        if (blockToDestroy && !blockToDestroy.isAir) {
                            if (!isBlockUnbreakable(blockToDestroy.typeId)) {
                                dim.runCommandAsync(`setblock ${Math.floor(targetX)} ${checkY} ${Math.floor(targetZ)} air replace`);
                            }
                        }
                    } catch (e) {}
                }
                newY = currentFootY;
            } else {
                let groundY = currentFootY;
                for (let checkY = currentFootY + 1; checkY >= currentFootY - 5; checkY--) {
                    const blockBelow = dim.getBlock({ x: Math.floor(targetX), y: checkY, z: Math.floor(targetZ) });
                    if (blockBelow && !blockBelow.isAir && !isPassableGrass(blockBelow.typeId)) {
                        groundY = checkY + 1;
                        break;
                    }
                }
                newY = groundY;
            }

            stalker.teleport({ x: targetX, y: newY, z: targetZ }, { dimension: dim });
        }
        faceTarget(stalker, player, true);
    } catch (e) {}
}

function getShakingText(text) {
    return "§c" + text;
}

system.runInterval(() => {
    const players = Array.from(world.getPlayers());
    if (players.length === 0) return;

    for (const player of players) {
        if (player.getGameMode() !== GameMode.survival && player.getGameMode() !== GameMode.adventure) {
            continue;
        }
        maybeSpawnStalker(player.dimension, player);
    }
}, 20);

// LOOP TELEPORTASI & ROTASI REALTIME (1 TICK)
system.runInterval(() => {
    const overworld = world.getDimension("overworld");
    const players = Array.from(world.getPlayers());

    if (players.length === 0) return;

    const stalkers = Array.from(overworld.getEntities({ type: STALKER_ID }));

    for (const stalker of stalkers) {
        if (!stalker.isValid()) continue;

        const data = stalkerData.get(stalker.id);

        let targetPlayer = null;
        let minDist = Infinity;
        for (const player of players) {
            const dist = Math.hypot(player.location.x - stalker.location.x, player.location.z - stalker.location.z);
            if (dist < minDist) {
                minDist = dist;
                targetPlayer = player;
            }
        }

        if (!targetPlayer) continue;

        const isChasing = data && data.state === "CHASING";
        faceTarget(stalker, targetPlayer, isChasing);

        if (isChasing) {
            moveChaser(stalker, targetPlayer, 0.55);
        }
    }
}, 1);

// LOOP AI UTAMA STALKER
system.runInterval(() => {
    const overworld = world.getDimension("overworld");
    const players = Array.from(world.getPlayers());

    if (players.length === 0) return;

    const stalkers = Array.from(overworld.getEntities({ type: STALKER_ID }));

    for (const [stalkerId] of stalkerData.entries()) {
        const exists = stalkers.some((s) => s.id === stalkerId);
        if (!exists) {
            stalkerData.delete(stalkerId);
        }
    }

    for (const stalker of stalkers) {
        if (!stalker.isValid()) continue;

        const sPos = stalker.location;
        let targetPlayer = null;
        let minDist = Infinity;

        for (const player of players) {
            const pPos = player.location;
            const dist = Math.hypot(pPos.x - sPos.x, pPos.y - sPos.y, pPos.z - sPos.z);

            if (dist < minDist) {
                minDist = dist;
                targetPlayer = player;
            }
        }

        if (!targetPlayer) continue;

        if (!stalkerData.has(stalker.id)) {
            stalkerData.set(stalker.id, {
                state: "WAITING",
                waitTimer: 0,
                chaseTimer: 0,
                effectTimer: 0,
                lifeTimer: 0,
                notLookedTimer: 0,
                sequenceTriggered: false
            });
        }

        const data = stalkerData.get(stalker.id);

        // SYSTEM DESPAWN PADA SAAT STALKER MUSIK SELESAI (760 TICKS)
        if (data.state === "CHASING") {
            data.lifeTimer += 5;
            if (data.lifeTimer >= 680) {
                try {
                    targetPlayer.removeEffect("darkness");
                } catch (e) {}

                stalkerData.delete(stalker.id);
                try {
                    stalker.remove();
                } catch (e) {}
                continue;
            }
        }

        const isSurvivalOrAdventure = targetPlayer.getGameMode() === GameMode.survival || targetPlayer.getGameMode() === GameMode.adventure;

        if (!isSurvivalOrAdventure) {
            try {
                targetPlayer.removeEffect("darkness");
            } catch (e) {}
        }

        const canSee = hasLineOfSight(targetPlayer, stalker);

        // MODE WAITING: DETEKSI 40 BLOK & TIMER 2 MENIT (2400 TICKS)
        if (data.state === "WAITING") {
            if (minDist <= 40) {
                data.waitTimer += 5;

                if (!canSee) {
                    data.notLookedTimer += 5;
                    if (data.notLookedTimer >= 100) {
                        playGlobalSound(targetPlayer, "keepsmiling:stalker_wait", 1.0, 1.0);
                        data.notLookedTimer = 0;
                    }
                } else {
                    data.notLookedTimer = 0;
                }

                // JIKA PLAYER MELIHAT KEARAH STALKER (DI DETIK BERAPAPUN)
                if (canSee && !data.sequenceTriggered) {
                    data.sequenceTriggered = true;
                    data.state = "WATCHING";

                    playGlobalSound(targetPlayer, "keepsmiling:stalker_watch", 1.0, 1.0);
                    playGlobalSound(targetPlayer, "keepsmiling:stalker_music", 1.0, 1.0);

                    targetPlayer.onScreenDisplay.setActionBar(getShakingText("DO NOT HIDE JUST RUN !"));

                    system.runTimeout(() => {
                        if (!stalker.isValid()) return;

                        data.state = "CHASING";

                        playGlobalSound(targetPlayer, "keepsmiling:stalker_scream", 1.0, 1.0);
                        stalker.triggerEvent("event:start_chase");

                        try {
                            targetPlayer.runCommandAsync("camerashake add @a 0.07 34 positional");
                        } catch (e) {}

                        if (isSurvivalOrAdventure) {
                            targetPlayer.addEffect("darkness", 100, { amplifier: 0, showParticles: false });
                        }
                    }, 40);
                }

                // JIKA SUDAH MENUNGGU 2 MENIT (2400 TICKS) SEBELUM DILIHAT PLAYER -> DESPAWN
                if (data.waitTimer >= 2400 && !canSee) {
                    stalkerData.delete(stalker.id);
                    try {
                        stalker.remove();
                    } catch (e) {}
                    continue;
                }
            }
        }

        if (data.state === "CHASING") {
            targetPlayer.onScreenDisplay.setActionBar(getShakingText("DO NOT HIDE JUST RUN !"));

            // LOOP SUARA CHASE DIUBAH TEPAT MENJADI 4.7 DETIK
            if (data.chaseTimer <= 0) {
                playGlobalSound(targetPlayer, "keepsmiling:stalker_chase", 1.0, 1.0);
                data.chaseTimer = 19; 
            } else {
                data.chaseTimer--;
            }

            if (isSurvivalOrAdventure) {
                if (data.effectTimer <= 0) {
                    targetPlayer.addEffect("darkness", 100, { amplifier: 0, showParticles: false });
                    data.effectTimer = 6;
                } else {
                    data.effectTimer--;
                }
            }
        }

        stalkerData.set(stalker.id, data);
    }
}, 5);

world.afterEvents.entityDie.subscribe((event) => {
    if (event.deadEntity.typeId === STALKER_ID) {
        stalkerData.delete(event.deadEntity.id);
    }
});

world.afterEvents.entityDie.subscribe((event) => {
    if (event.deadEntity.typeId === "minecraft:player") {
        const player = event.deadEntity;

        try {
            player.removeEffect("darkness");
            player.removeEffect("night_vision");
        } catch (e) {}

        const overworld = world.getDimension("overworld");
        const stalkers = Array.from(overworld.getEntities({ type: STALKER_ID }));

        for (const stalker of stalkers) {
            stalkerData.delete(stalker.id);
            try {
                stalker.remove();
            } catch (e) {}
        }
    }
});
