import { world, system, GameMode } from "@minecraft/server";

const SMILER_ID = "keepsmiling:smiler";
const UNBREAKABLE = [
    "minecraft:bedrock",
    "minecraft:reinforced_deepslate",
    "minecraft:barrier",
    "minecraft:command_block",
    "minecraft:repeating_command_block",
    "minecraft:chain_command_block"
];

const smilerStates = new Map();
let nextAllowedDayToSpawn = -1;
let playerLastSpawnCheck = new Map();

function isNightOrSunset() {
    const timeOfDay = world.getTimeOfDay();
    return timeOfDay >= 12000 && timeOfDay <= 23000;
}

function hasActive(dimension, typeId) {
    try {
        return Array.from(dimension.getEntities({ type: typeId })).length > 0;
    } catch (e) {
        return false;
    }
}

// MENCARI PERMUKAAN TANAH PALING ATAS (SURFACE) SEHINGGA TIDAK SPAWN DI CAVE
function getSurfaceY(dimension, x, z) {
    const checkX = Math.floor(x);
    const checkZ = Math.floor(z);
    
    for (let y = 310; y >= -64; y--) {
        try {
            const b = dimension.getBlock({ x: checkX, y: y, z: checkZ });
            if (b && !b.isAir && !b.isLiquid) {
                return y + 1;
            }
        } catch (e) {}
    }
    return 70;
}

function findSurfaceSpot(dimension, pLoc, minDist, maxDist, skyCheck) {
    try {
        const angle = Math.random() * Math.PI * 2;
        const dist = minDist + Math.random() * (maxDist - minDist);
        const spawnX = pLoc.x + Math.cos(angle) * dist;
        const spawnZ = pLoc.z + Math.sin(angle) * dist;
        const spawnY = getSurfaceY(dimension, spawnX, spawnZ);

        return { x: spawnX, y: spawnY, z: spawnZ };
    } catch (e) {
        return null;
    }
}

function duePlayer(player, key, cooldownTicks) {
    const currentTick = world.getAbsoluteTime();
    const lastTick = playerLastSpawnCheck.get(`${player.id}_${key}`) || 0;
    if (currentTick - lastTick >= cooldownTicks) {
        playerLastSpawnCheck.set(`${player.id}_${key}`, currentTick);
        return true;
    }
    return false;
}

// FUNGSI MAYBE SPAWN SMILER SESUAI KODE REFERENSI KAMU (KHUSUS MALAM HARI / SUNSET)
function maybeSpawnSmiler(dimension, player) {
    if (!duePlayer(player, "smiler", 20 * 34)) return;
    if (!isNightOrSunset() || hasActive(dimension, SMILER_ID)) return;
    if (Math.random() > 0.15) return;

    const currentDay = Math.floor(world.getAbsoluteTime() / 24000);
    if (currentDay < nextAllowedDayToSpawn) return;

    const pos = findSurfaceSpot(dimension, player.location, 24, 48, 32);
    if (!pos) return;

    try {
        const entity = dimension.spawnEntity(SMILER_ID, pos);
        if (entity) {
            entity.setDynamicProperty("isNaturalSpawn", true);

            try {
                dimension.playSound("keepsmiling:smiler_spawn", pos, { volume: 5.0 });
            } catch (e) {}

            smilerStates.set(entity.id, { 
                phase: "idle", 
                lookTicks: 0, 
                isBeingLooked: false,
                soundTimer: 0,
                chaseTimer: 0,
                targetId: player.id
            });

            const randomDayCooldown = Math.floor(Math.random() * 3) + 1;
            nextAllowedDayToSpawn = currentDay + randomDayCooldown;
        }
    } catch (e) {}
}

function isFlower(typeId) {
    if (!typeId) return false;
    const id = typeId.toLowerCase();
    return id.includes("flower") || id.includes("rose") || id.includes("dandelion") || 
           id.includes("poppy") || id.includes("orchid") || id.includes("allium") || 
           id.includes("tulip") || id.includes("daisy") || id.includes("cornflower") || 
           id.includes("lily") || id.includes("sunflower") || id.includes("lilac") || 
           id.includes("peony") || id.includes("pitcher") || id.includes("torchflower");
}

function isPassableGrass(typeId) {
    if (!typeId) return false;
    const id = typeId.toLowerCase();
    return id.includes("short_grass") || id.includes("tall_grass") || 
          (id.includes("grass") && !id.includes("block") && !id.includes("path"));
}

function isBlockUnbreakable(typeId) {
    if (!typeId) return false;
    const id = typeId.toLowerCase();
    return UNBREAKABLE.some(unb => id === unb || id.includes("bedrock") || id.includes("reinforced_deepslate"));
}

function applyCameraEffects(player) {
    try {
        player.runCommandAsync("camerashake add @s 0.18 2 positional");
        player.addEffect("slowness", 10, { amplifier: 4, showParticles: false });
        player.addEffect("speed", 10, { amplifier: 5, showParticles: false });
    } catch (e) {}
}

function stopCameraEffects(player) {
    try {
        player.runCommandAsync("camerashake stop @s");
        player.removeEffect("slowness");
        player.removeEffect("speed");
    } catch (e) {}
}

function stopSmilerSound(player) {
    try {
        player.runCommandAsync("stopsound @s keepsmiling:smiler_look");
        stopCameraEffects(player);
    } catch (e) {}
}

function moveChaser(smiler, player, speed) {
    try {
        const dim = smiler.dimension;
        const sLoc = smiler.location;
        const pLoc = player.location;

        const dx = pLoc.x - sLoc.x;
        const dz = pLoc.z - sLoc.z;
        const dist = Math.hypot(dx, dz);

        if (dist > 0.8) {
            let vx = (dx / dist) * speed;
            let vz = (dz / dist) * speed;

            let targetX = sLoc.x + vx;
            let targetZ = sLoc.z + vz;

            const currentFootY = Math.floor(sLoc.y);

            const currentBlockAtFoot = dim.getBlock({ x: Math.floor(targetX), y: currentFootY, z: Math.floor(targetZ) });
            if (currentBlockAtFoot && isFlower(currentBlockAtFoot.typeId)) {
                dim.runCommandAsync(`setblock ${Math.floor(targetX)} ${currentFootY} ${Math.floor(targetZ)} air replace`);
            }

            let wallHeight = 0;
            let isUnbreakableObstacle = false;

            for (let checkY = currentFootY; checkY <= currentFootY + 10; checkY++) {
                const b = dim.getBlock({ x: Math.floor(targetX), y: checkY, z: Math.floor(targetZ) });
                if (b && !b.isAir) {
                    if (isPassableGrass(b.typeId)) continue;
                    if (isFlower(b.typeId)) {
                        dim.runCommandAsync(`setblock ${Math.floor(targetX)} ${checkY} ${Math.floor(targetZ)} air replace`);
                        continue;
                    }
                    if (isBlockUnbreakable(b.typeId)) {
                        isUnbreakableObstacle = true;
                    }
                    wallHeight++;
                } else {
                    break;
                }
            }

            let newY = sLoc.y;

            if (isUnbreakableObstacle) {
                const sideLeftX = Math.floor(sLoc.x - vz * 2);
                const sideLeftZ = Math.floor(sLoc.z + vx * 2);
                const blockLeft = dim.getBlock({ x: sideLeftX, y: currentFootY, z: sideLeftZ });

                if (!blockLeft || blockLeft.isAir || !isBlockUnbreakable(blockLeft.typeId)) {
                    targetX = sLoc.x - vz * speed;
                    targetZ = sLoc.z + vx * speed;
                } else {
                    targetX = sLoc.x + vz * speed;
                    targetZ = sLoc.z - vx * speed;
                }
                newY = currentFootY;
            } else if (wallHeight === 1) {
                newY = currentFootY + 1;
            } else if (wallHeight >= 2) {
                for (let offsetY = 0; offsetY < wallHeight + 2; offsetY++) {
                    const checkY = currentFootY + offsetY;
                    try {
                        const blockToDestroy = dim.getBlock({ x: Math.floor(targetX), y: checkY, z: Math.floor(targetZ) });
                        if (blockToDestroy && !blockToDestroy.isAir) {
                            if (!isBlockUnbreakable(blockToDestroy.typeId)) {
                                dim.runCommandAsync(`setblock ${Math.floor(targetX)} ${checkY} ${Math.floor(targetZ)} air replace`);
                            }
                        }
                    } catch (e) {}
                }
                newY = currentFootY;
            } else {
                let groundY = currentFootY;
                for (let checkY = currentFootY + 1; checkY >= currentFootY - 5; checkY--) {
                    const blockBelow = dim.getBlock({ x: Math.floor(targetX), y: checkY, z: Math.floor(targetZ) });
                    if (blockBelow && !blockBelow.isAir && !isPassableGrass(blockBelow.typeId)) {
                        groundY = checkY + 1;
                        break;
                    }
                }
                newY = groundY;
            }

            smiler.teleport({ x: targetX, y: newY, z: targetZ }, { dimension: dim });
        }
        faceTarget(smiler, player, true);
    } catch (e) {}
}

function faceTarget(smiler, player, isChasing = false) {
    try {
        const pHead = player.getHeadLocation();
        const pLoc = player.location;
        const sLoc = smiler.location;

        const dx = pHead.x - sLoc.x;
        const dy = pHead.y - (sLoc.y + 1.2);
        const dz = pHead.z - sLoc.z;

        const distXZ = Math.hypot(dx, dz);
        const yaw = (Math.atan2(dz, dx) * 180) / Math.PI - 90;

        let pitch = 0;
        if (distXZ < 0.01) {
            pitch = dy > 0 ? 89.9 : -89.9;
        } else {
            pitch = (Math.atan2(dy, distXZ) * 180) / Math.PI;
        }

        const yDiff = Math.abs(pLoc.y - sLoc.y);
        const isGroundLevel = yDiff <= 1.5;

        if (isChasing && isGroundLevel && distXZ < 6.5) {
            const leanOffset = Math.sin((6.5 - distXZ) / 6.5 * (Math.PI / 2)) * 22.0;
            pitch -= leanOffset;
        }

        pitch = Math.max(-89.9, Math.min(89.9, pitch));
        smiler.setRotation({ x: pitch, y: yaw });
    } catch (e) {}
}

function hasLineOfSight(player, smiler) {
    try {
        const pHead = player.getHeadLocation();
        const sHead = { x: smiler.location.x, y: smiler.location.y + 1.5, z: smiler.location.z };

        const rayResult = player.dimension.getBlockFromRay(pHead, {
            x: sHead.x - pHead.x,
            y: sHead.y - pHead.y,
            z: sHead.z - pHead.z
        }, {
            maxDistance: Math.hypot(sHead.x - pHead.x, sHead.y - pHead.y, sHead.z - pHead.z),
            includeLiquidBlocks: false,
            includePassableBlocks: false
        });

        if (rayResult && rayResult.block) {
            const b = rayResult.block.typeId.toLowerCase();
            const isTransparent = b.includes("glass") || b.includes("pane") || b.includes("fence") || b.includes("trapdoor") || b.includes("iron_bars");
            if (!isTransparent) return false;
        }
        return true;
    } catch (e) {
        return false;
    }
}

function lookingPlayerFor(smiler, player) {
    try {
        if (!hasLineOfSight(player, smiler)) return false;

        const pHead = player.getHeadLocation();
        const vVec = player.getViewDirection();
        const toSmiler = {
            x: smiler.location.x - pHead.x,
            y: smiler.location.y + 1.5 - pHead.y,
            z: smiler.location.z - pHead.z
        };

        const dist = Math.sqrt(toSmiler.x * toSmiler.x + toSmiler.y * toSmiler.y + toSmiler.z * toSmiler.z);
        const norm = { x: toSmiler.x / dist, y: toSmiler.y / dist, z: toSmiler.z / dist };
        const dot = vVec.x * norm.x + vVec.y * norm.y + vVec.z * norm.z;

        return dot > 0.35;
    } catch (e) {
        return false;
    }
}

// RESET SAAT PLAYER MATI
world.afterEvents.entityDie.subscribe((event) => {
    const deadEntity = event.deadEntity;
    if (deadEntity && deadEntity.typeId === "minecraft:player") {
        try {
            deadEntity.runCommandAsync("stopsound @a keepsmiling:smiler_music");
            deadEntity.runCommandAsync("stopsound @a keepsmiling:smiler_chase");
            deadEntity.runCommandAsync("stopsound @a keepsmiling:smiler_look");
            stopCameraEffects(deadEntity);
            deadEntity.onScreenDisplay.setActionBar("");
        } catch (e) {}

        const overworld = world.getDimension("overworld");
        const smilers = Array.from(overworld.getEntities({ type: SMILER_ID }));
        for (const smiler of smilers) {
            smiler.remove();
            smilerStates.delete(smiler.id);
        }
    }
});

// SPAWNER ALAMI SMILER DENGAN FUNGSI MAYBE SPAWN SMILER
system.runInterval(() => {
    const overworld = world.getDimension("overworld");
    const players = Array.from(world.getPlayers());

    for (const player of players) {
        if (player.getGameMode() !== GameMode.survival && player.getGameMode() !== GameMode.adventure) continue;
        maybeSpawnSmiler(overworld, player);
    }
}, 100);

// LOOP PERGERAKAN CHASE REALTIME (1 TICK)
system.runInterval(() => {
    const overworld = world.getDimension("overworld");
    const smilers = Array.from(overworld.getEntities({ type: SMILER_ID }));
    const players = Array.from(world.getPlayers());

    if (players.length === 0) return;

    for (const smiler of smilers) {
        if (!smiler.isValid()) continue;

        const data = smilerStates.get(smiler.id);
        if (data && data.phase === "chase") {
            let target = players.find(p => p.id === data.targetId);
            if (!target) {
                let minDist = Infinity;
                for (const p of players) {
                    const d = Math.hypot(p.location.x - smiler.location.x, p.location.z - smiler.location.z);
                    if (d < minDist) {
                        minDist = d;
                        target = p;
                    }
                }
            }

            if (target) {
                moveChaser(smiler, target, 0.88);
            }
        }
    }
}, 1);

// LOOP UTAMA LOGIKA AI (BERJALAN TIAP 2 TICK UNTUK PERHITUNGAN DATA)
system.runInterval(() => {
    const overworld = world.getDimension("overworld");
    const smilers = Array.from(overworld.getEntities({ type: SMILER_ID }));
    const players = Array.from(world.getPlayers());

    for (const smiler of smilers) {
        if (!smiler.isValid()) continue;

        let data = smilerStates.get(smiler.id) || { phase: "idle", lookTicks: 0, isBeingLooked: false, soundTimer: 0, chaseTimer: 0, targetId: null };
        let target = null;

        if (data.phase === "idle") {
            let lookingPlayer = null;
            let closestPlayer = null;
            let minDist = Infinity;

            for (const p of players) {
                const d = Math.hypot(p.location.x - smiler.location.x, p.location.z - smiler.location.z);
                if (d < minDist) {
                    minDist = d;
                    closestPlayer = p;
                }
                if (lookingPlayerFor(smiler, p)) {
                    lookingPlayer = p;
                }
            }

            target = lookingPlayer || closestPlayer;
            if (!target) continue;

            data.targetId = target.id;
            faceTarget(smiler, target, false);

            const isLooking = lookingPlayerFor(smiler, target);

            if (isLooking) {
                data.lookTicks++;
                
                if (!data.isBeingLooked || data.soundTimer <= 0) {
                    try {
                        target.runCommandAsync("playsound keepsmiling:smiler_look @s");
                    } catch (e) {}
                    data.isBeingLooked = true;
                    data.soundTimer = 40;
                } else {
                    data.soundTimer -= 2;
                }

                applyCameraEffects(target);
                target.onScreenDisplay.setActionBar("§cDONT LOOK AT HIM");

                const isSurvivalOrAdventure = target.getGameMode() === GameMode.survival || target.getGameMode() === GameMode.adventure;

                if (isSurvivalOrAdventure && (data.lookTicks >= 50 || minDist <= 3.5)) {
                    triggerChase(smiler, target, data);
                }
            } else {
                if (data.isBeingLooked) {
                    stopSmilerSound(target);
                    data.isBeingLooked = false;
                    data.soundTimer = 0;
                    target.onScreenDisplay.setActionBar("");
                }
                data.lookTicks = 0;
            }
        } 
        else if (data.phase === "chase") {
            data.chaseTimer += 2;

            if (data.chaseTimer >= 1340) {
                try {
                    overworld.runCommandAsync("stopsound @a keepsmiling:smiler_music");
                    overworld.runCommandAsync("stopsound @a keepsmiling:smiler_chase");
                    for (const p of players) {
                        stopCameraEffects(p);
                        p.onScreenDisplay.setActionBar("");
                    }
                } catch (e) {}

                smiler.remove();
                smilerStates.delete(smiler.id);
                continue;
            }

            let closestPlayer = null;
            let minDist = Infinity;
            for (const p of players) {
                const d = Math.hypot(p.location.x - smiler.location.x, p.location.z - smiler.location.z);
                if (d < minDist) {
                    minDist = d;
                    closestPlayer = p;
                }
            }

            if (closestPlayer && minDist <= 2.5) {
                data.targetId = closestPlayer.id;
                target = closestPlayer;
            } else {
                target = players.find(p => p.id === data.targetId) || closestPlayer;
            }

            if (!target) continue;

            for (const p of players) {
                const isSurvivalOrAdventure = p.getGameMode() === GameMode.survival || p.getGameMode() === GameMode.adventure;
                if (isSurvivalOrAdventure) {
                    p.addEffect("darkness", 40, { amplifier: 1, showParticles: false });
                }
            }

            target.onScreenDisplay.setActionBar("§cGood luck...");
        }

        smilerStates.set(smiler.id, data);
    }
}, 2);

function triggerChase(smiler, player, data) {
    data.phase = "chase";
    data.chaseTimer = 0;
    const dim = smiler.dimension;
    try {
        dim.runCommandAsync("stopsound @a keepsmiling:smiler_look");
        stopCameraEffects(player);
        dim.runCommandAsync("playsound keepsmiling:smiler_chase @a");
        dim.runCommandAsync("playsound keepsmiling:smiler_music @a");
    } catch (e) {}
}
