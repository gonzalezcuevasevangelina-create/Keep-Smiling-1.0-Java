import { world, system } from "@minecraft/server";

const JUMPSCARE_ID = "keepsmiling:bipedal_jumpscare";
const activeJumpscares = new Map();

// Helper matematika vektor & rotasi
function vecSub(a, b) {
    return { x: a.x - b.x, y: a.y - b.y, z: a.z - b.z };
}

function vecLen(v) {
    return Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
}

function vecNorm(v) {
    const l = vecLen(v) || 1;
    return { x: v.x / l, y: v.y / l, z: v.z / l };
}

function vecDot(a, b) {
    return a.x * b.x + a.y * b.y + a.z * b.z;
}

function yawToForward(yawDeg) {
    const rad = (yawDeg * Math.PI) / 180;
    return { x: -Math.sin(rad), y: 0, z: Math.cos(rad) };
}

// Cari player terdekat dari entitas
function getClosestPlayer(entity) {
    const players = entity.dimension.getPlayers({
        location: entity.location,
        maxDistance: 32
    });
    if (players.length === 0) return undefined;
    
    let closest = players[0];
    let minSquareDist = Infinity;
    for (const p of players) {
        const dx = p.location.x - entity.location.x;
        const dy = p.location.y - entity.location.y;
        const dz = p.location.z - entity.location.z;
        const sqDist = dx * dx + dy * dy + dz * dz;
        if (sqDist < minSquareDist) {
            minSquareDist = sqDist;
            closest = p;
        }
    }
    return closest;
}

// Mengunci paksa kamera player ke posisi entitas
function lockCameraToEntity(player, entity) {
    try {
        let pHead;
        try {
            pHead = player.getHeadLocation();
        } catch (e) {
            pHead = { x: player.location.x, y: player.location.y + 1.62, z: player.location.z };
        }

        const eLoc = { x: entity.location.x, y: entity.location.y + 1.5, z: entity.location.z };

        const dx = eLoc.x - pHead.x;
        const dy = eLoc.y - pHead.y;
        const dz = eLoc.z - pHead.z;

        const distXZ = Math.hypot(dx, dz);
        const yaw = (Math.atan2(dz, dx) * 180) / Math.PI - 90;
        const pitch = (Math.atan2(-dy, distXZ) * 180) / Math.PI;

        player.setRotation({ x: pitch, y: yaw });
    } catch (e) {}
}

// Memeriksa apakah sudut pandang mata player menghadap ke entitas
function isPlayerLookingAtJumpscare(player, entity) {
    try {
        let pHead;
        try {
            pHead = player.getHeadLocation();
        } catch (e) {
            pHead = { x: player.location.x, y: player.location.y + 1.62, z: player.location.z };
        }

        const eLoc = entity.location;
        const toEntity = vecSub(eLoc, pHead);
        const dist = vecLen(toEntity);

        if (dist > 15 || dist < 0.3) return false;

        const dirToEntity = vecNorm(toEntity);
        const viewDir = player.getViewDirection();
        const dot = vecDot(viewDir, dirToEntity);

        return dot > 0.45;
    } catch (e) {
        return false;
    }
}

// Handler Pendaftaran Entitas (Bisa dari Spawn Egg, /summon, maupun World Spawn)
world.afterEvents.entitySpawn.subscribe((event) => {
    const { entity } = event;
    if (entity?.typeId !== JUMPSCARE_ID) return;
    if (activeJumpscares.has(entity.id)) return;

    system.runTimeout(() => {
        if (!entity.isValid()) return;
        const targetPlayer = getClosestPlayer(entity);
        if (!targetPlayer) return;

        activeJumpscares.set(entity.id, {
            state: "WAITING",
            entity: entity,
            targetPlayer: targetPlayer,
            chatSpamTimer: 0,
            timer: 0
        });
    }, 2);
});

// Event listener saat pemain pertama kali masuk world baru (initialSpawn)
world.afterEvents.playerSpawn.subscribe((event) => {
    const { player, initialSpawn } = event;
    
    if (!initialSpawn) return;

    system.runTimeout(() => {
        if (!player.isValid()) return;

        const dim = player.dimension;
        const pLoc = player.location;
        const forward = yawToForward(player.getRotation().y);

        // Position spawn: 3 block tepat di belakang player
        const spawnX = pLoc.x - forward.x * 3;
        const spawnZ = pLoc.z - forward.z * 3;
        const spawnY = pLoc.y;

        const spawnPos = { x: spawnX, y: spawnY, z: spawnZ };

        try {
            const jumpscareEntity = dim.spawnEntity(JUMPSCARE_ID, spawnPos);

            // Menghadapkan entitas ke arah tubuh player
            const dx = pLoc.x - spawnX;
            const dz = pLoc.z - spawnZ;
            const yaw = (Math.atan2(-dx, dz) * 180) / Math.PI;
            jumpscareEntity.setRotation({ x: 0, y: yaw });

            activeJumpscares.set(jumpscareEntity.id, {
                state: "WAITING",
                entity: jumpscareEntity,
                targetPlayer: player,
                chatSpamTimer: 0,
                timer: 0
            });
        } catch (e) {}
    }, 20);
});

// Main Loop: Berjalan setiap 1-tick untuk penguncian kamera & pembacaan trigger
system.runInterval(() => {
    for (const [id, data] of activeJumpscares) {
        const { entity } = data;
        let { targetPlayer } = data;

        if (!entity || !entity.isValid()) {
            activeJumpscares.delete(id);
            continue;
        }

        if (!targetPlayer || !targetPlayer.isValid()) {
            targetPlayer = getClosestPlayer(entity);
            if (!targetPlayer) continue;
            data.targetPlayer = targetPlayer;
        }

        if (data.state === "WAITING") {
            // Menunggu hingga pemain menengok ke belakang / ke arah entitas
            if (isPlayerLookingAtJumpscare(targetPlayer, entity)) {
                data.state = "TRIGGERED";
                data.timer = 0;

                // Memutar audio welcome_to_the_parallel.ogg
                try {
                    targetPlayer.runCommandAsync("playsound keepsmiling:welcome_to_the_parallel @s");
                } catch (e) {}
            }
        } else if (data.state === "TRIGGERED") {
            // 1. Kunci paksa kamera player setiap tick
            lockCameraToEntity(targetPlayer, entity);

            // 2. Spam pesan merah di chat setiap 2 tick
            if (data.chatSpamTimer % 2 === 0) {
                try {
                    targetPlayer.sendMessage("§cWELCOME TO THE PARALLEL");
                } catch (e) {}
            }
            data.chatSpamTimer++;

            // 3. Durasi jumpscare 2 detik (40 ticks), setelah itu entitas despawn/hilang
            data.timer++;
            if (data.timer >= 40) {
                try {
                    entity.remove();
                } catch (e) {}
                activeJumpscares.delete(id);
            }
        }
    }
}, 1);
