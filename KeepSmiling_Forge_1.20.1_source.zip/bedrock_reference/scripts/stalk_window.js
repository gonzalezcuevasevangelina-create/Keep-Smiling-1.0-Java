import { world, system, GameMode } from "@minecraft/server";

const STALK_WINDOW_ID = "keepsmiling:stalk_window";
const stalkWindowStates = new Map();

let nextAllowedDayToSpawn = -1;

function isGlassOrTransparentBlock(typeId) {
    if (!typeId) return false;
    const lower = typeId.toLowerCase();
    return lower.includes("glass") || lower.includes("pane") || lower.includes("trapdoor") || lower.includes("fence");
}

// DETEKSI PRESISI SISI LUAR KACA DENGAN JAMINAN 100% DI LUAR RUMAH
function findOutsideGlassPos(player) {
    try {
        const dim = player.dimension;
        const pLoc = player.location;
        const px = Math.floor(pLoc.x);
        const py = Math.floor(pLoc.y);
        const pz = Math.floor(pLoc.z);

        const radius = 10;
        const candidateGlass = [];

        for (let x = px - radius; x <= px + radius; x++) {
            for (let z = pz - radius; z <= pz + radius; z++) {
                for (let y = py - 2; y <= py + 4; y++) {
                    const block = dim.getBlock({ x: x, y: y, z: z });
                    
                    if (block && isGlassOrTransparentBlock(block.typeId)) {
                        const neighbors = [
                            { block: dim.getBlock({ x: x + 1, y: y, z: z }), dirX: 1, dirZ: 0 },
                            { block: dim.getBlock({ x: x - 1, y: y, z: z }), dirX: -1, dirZ: 0 },
                            { block: dim.getBlock({ x: x, y: y, z: z + 1 }), dirX: 0, dirZ: 1 },
                            { block: dim.getBlock({ x: x, y: y, z: z - 1 }), dirX: 0, dirZ: -1 }
                        ];

                        // Filter blok padat tetangga
                        const hasSolidNeighbor = neighbors.some(n => n.block && !n.block.isAir && !isGlassOrTransparentBlock(n.block.typeId));
                        if (!hasSolidNeighbor) continue;

                        // Cari blok udara tetangga yang posisinya LEBIH JAUH dari pemain dibanding kaca (pasti di luar rumah)
                        const distToGlass = Math.hypot(pLoc.x - (x + 0.5), pLoc.z - (z + 0.5));
                        let bestOutsideNeighbor = null;
                        let maxDist = distToGlass;

                        for (const n of neighbors) {
                            if (n.block && (n.block.isAir || isGlassOrTransparentBlock(n.block.typeId))) {
                                const nX = x + 0.5 + n.dirX;
                                const nZ = z + 0.5 + n.dirZ;
                                const distToN = Math.hypot(pLoc.x - nX, pLoc.z - nZ);

                                if (distToN > maxDist) {
                                    maxDist = distToN;
                                    bestOutsideNeighbor = n;
                                }
                            }
                        }

                        if (bestOutsideNeighbor) {
                            const targetX = x + 0.5 + bestOutsideNeighbor.dirX * 0.55;
                            const targetZ = z + 0.5 + bestOutsideNeighbor.dirZ * 0.55;
                            const targetY = y + 0.3;

                            candidateGlass.push({
                                spawnPos: { x: targetX, y: targetY, z: targetZ },
                                glassPos: { x: x + 0.5, y: y, z: z + 0.5 },
                                slideDir: { x: bestOutsideNeighbor.dirZ, z: -bestOutsideNeighbor.dirX }
                            });
                        }
                    }
                }
            }
        }

        if (candidateGlass.length > 0) {
            return candidateDoorsOrGlass(player, candidateGlass);
        }
        return null;
    } catch (e) {
        return null;
    }
}

function candidateDoorsOrGlass(player, candidates) {
    let best = candidates[0];
    let minD = Infinity;
    const pLoc = player.location;

    for (const c of candidates) {
        const d = Math.hypot(pLoc.x - c.spawnPos.x, pLoc.z - c.spawnPos.z);
        if (d < minD) {
            minD = d;
            best = c;
        }
    }
    return best;
}

function isPlayerLookingAtWindow(player, stalkWindow) {
    try {
        const pHead = player.getHeadLocation();
        const sLoc = stalkWindow.location;

        const dx = sLoc.x - pHead.x;
        const dy = sLoc.y - pHead.y;
        const dz = sLoc.z - pHead.z;
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

        if (dist > 18) return false;

        const viewDir = player.getViewDirection();
        const dot = viewDir.x * (dx / dist) + viewDir.y * (dy / dist) + viewDir.z * (dz / dist);

        return dot > 0.55;
    } catch (e) {
        return false;
    }
}

// SYSTEM SPAWN NATURAL
system.runInterval(() => {
    const players = Array.from(world.getPlayers());
    if (players.length === 0) return;

    const overworld = world.getDimension("overworld");
    const currentDay = Math.floor(world.getAbsoluteTime() / 24000);
    if (currentDay < nextAllowedDayToSpawn) return;

    const existing = Array.from(overworld.getEntities({ type: STALK_WINDOW_ID }));
    if (existing.length >= 1) return;

    for (const player of players) {
        if (player.getGameMode() !== GameMode.survival && player.getGameMode() !== GameMode.adventure) continue;
        if (Math.random() > 0.30) continue;

        const spawnData = findOutsideGlassPos(player);
        if (spawnData) {
            try {
                const entity = overworld.spawnEntity(STALK_WINDOW_ID, spawnData.spawnPos);

                stalkWindowStates.set(entity.id, {
                    state: "IDLE",
                    timer: 0,
                    spawnPos: spawnData.spawnPos,
                    slideDir: spawnData.slideDir,
                    targetPlayer: player
                });

                player.runCommandAsync("playsound keepsmiling:stalk_window_hi @s");
                nextAllowedDayToSpawn = currentDay + Math.floor(Math.random() * 3) + 2;
                break;
            } catch (e) {}
        }
    }
}, 100);

// HANDLER SPAWN MANUAL (SPAWN EGG / SUMMON COMMAND)
world.afterEvents.entitySpawn.subscribe((event) => {
    const entity = event.entity;
    if (entity.typeId === STALK_WINDOW_ID) {
        system.runTimeout(() => {
            if (!stalkWindowStates.has(entity.id)) {
                const players = Array.from(world.getPlayers());
                let attached = false;

                if (players.length > 0) {
                    const player = players[0];
                    const spawnData = findOutsideGlassPos(player);

                    if (spawnData) {
                        entity.teleport(spawnData.spawnPos);
                        stalkWindowStates.set(entity.id, {
                            state: "IDLE",
                            timer: 0,
                            spawnPos: spawnData.spawnPos,
                            slideDir: spawnData.slideDir,
                            targetPlayer: player
                        });

                        player.runCommandAsync("playsound keepsmiling:stalk_window_hi @s");
                        attached = true;
                    }
                }

                if (!attached) {
                    try { entity.remove(); } catch (e) {}
                }
            }
        }, 2);
    }
});

// MAIN TICK LOOP (LOGIKA SLIDE SMOOTH KE BAWAH-KIRI)
system.runInterval(() => {
    const overworld = world.getDimension("overworld");
    const stalkWindows = Array.from(overworld.getEntities({ type: STALK_WINDOW_ID }));

    for (const entity of stalkWindows) {
        if (!entity.isValid()) continue;

        let data = stalkWindowStates.get(entity.id);
        if (!data) continue;

        const player = data.targetPlayer;
        if (!player || !player.isValid()) {
            entity.remove();
            stalkWindowStates.delete(entity.id);
            continue;
        }

        if (data.state === "IDLE") {
            const isSeen = isPlayerLookingAtWindow(player, entity);

            if (isSeen) {
                data.state = "SLIDING";
                data.timer = 0;
            }
        }
        else if (data.state === "SLIDING") {
            data.timer += 1;

            const eLoc = entity.location;
            const newX = eLoc.x + data.slideDir.x * 0.045;
            const newY = eLoc.y - 0.035;
            const newZ = eLoc.z + data.slideDir.z * 0.045;

            entity.teleport({ x: newX, y: newY, z: newZ }, { dimension: overworld });

            if (data.timer >= 35) {
                stalkWindowStates.delete(entity.id);
                try { entity.remove(); } catch (e) {}
            }
        }
    }
}, 1);

// CLEANUP SAAT PLAYER MATI
world.afterEvents.entityDie.subscribe((event) => {
    if (event.deadEntity && event.deadEntity.typeId === "minecraft:player") {
        const overworld = world.getDimension("overworld");
        const stalkWindows = Array.from(overworld.getEntities({ type: STALK_WINDOW_ID }));
        for (const entity of stalkWindows) {
            stalkWindowStates.delete(entity.id);
            try { entity.remove(); } catch (e) {}
        }
    }
});
