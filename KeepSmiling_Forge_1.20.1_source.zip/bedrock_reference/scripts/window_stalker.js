import { world, system, GameMode } from "@minecraft/server";

const STALKER_ID = "keepsmiling:window_stalker";
const UNBREAKABLE = [
    "minecraft:bedrock", 
    "minecraft:reinforced_deepslate", 
    "minecraft:barrier", 
    "minecraft:command_block"
];

const windowStalkerStates = new Map();

// LOGIKA STATE & TIMING
const STATE = {
    windowStalkerActive: false,
    windowStalkerCooldownUntil: 0
};

const DAY_CHANCE = 0.30;
const NIGHT_CHANCE = 0.60;

function gameTime() {
    return world.getAbsoluteTime();
}

function isDay() {
    const time = world.getTimeOfDay();
    return time >= 0 && time < 12000;
}

function hasActive(dimension, typeId) {
    return Array.from(dimension.getEntities({ type: typeId })).length > 0;
}

function isWindowBlock(typeId) {
    if (!typeId) return false;
    const lower = typeId.toLowerCase();
    return lower.includes("glass") || lower.includes("glass_pane");
}

function isPassableGrass(typeId) {
    if (!typeId) return false;
    const id = typeId.toLowerCase();
    return id.includes("short_grass") || id.includes("tall_grass") || 
          (id.includes("grass") && !id.includes("block") && !id.includes("path"));
}

function isBlockUnbreakable(typeId) {
    if (!typeId) return false;
    const id = typeId.toLowerCase();
    return UNBREAKABLE.some(unb => id === unb || id.includes("bedrock") || id.includes("reinforced_deepslate"));
}

function destroyObstacleBlock(dim, x, y, z) {
    try {
        const block = dim.getBlock({ x: Math.floor(x), y: Math.floor(y), z: Math.floor(z) });
        if (block && !block.isAir && !isBlockUnbreakable(block.typeId)) {
            block.setType("minecraft:air");
        }
    } catch (e) {}
}

function face(entity, player) {
    try {
        const pLoc = player.location;
        const eLoc = entity.location;
        const dx = pLoc.x - eLoc.x;
        const dz = pLoc.z - eLoc.z;
        const yaw = (Math.atan2(dz, dx) * 180) / Math.PI - 90;
        entity.teleport(eLoc, { rotation: { x: 0, y: yaw } });
    } catch (e) {}
}

function findBehindPlayerSpot(dimension, player, minDist, maxDist) {
    try {
        const pLoc = player.location;
        const vDir = player.getViewDirection();
        const dist = minDist + Math.random() * (maxDist - minDist);
        
        const targetX = pLoc.x - vDir.x * dist;
        const targetZ = pLoc.z - vDir.z * dist;
        
        return { x: targetX, y: pLoc.y, z: targetZ };
    } catch (e) {
        return null;
    }
}

// PENGECEKAN KELUAR RUMAH / ATAP TERBUKA (MIRIP ADDON LAIN)
function isPlayerInsideHouse(player) {
    try {
        const dim = player.dimension;
        const pLoc = player.location;
        const px = Math.floor(pLoc.x);
        const py = Math.floor(pLoc.y);
        const pz = Math.floor(pLoc.z);

        // Cek lurus ke atas dari atas kepala pemain (y + 2) sampai ke batas atas dunia (y = 320)
        for (let y = py + 2; y <= 320; y++) {
            const block = dim.getBlock({ x: px, y: y, z: pz });
            // Jika menemukan blok padat di atas kepala, pemain dianggap ada di dalam rumah / tertutup atap
            if (block && !block.isAir) {
                return true; 
            }
        }

        // Jika dari kepala sampai batas langit tidak ada blok padat sama sekali, pemain berada di luar rumah
        return false; 
    } catch (e) {
        return false;
    }
}

function findOutsideWindowPos(player) {
    try {
        const dim = player.dimension;
        const pLoc = player.location;
        const px = Math.floor(pLoc.x);
        const py = Math.floor(pLoc.y);
        const pz = Math.floor(pLoc.z);

        const radius = 12;
        const candidateWindows = [];

        for (let x = px - radius; x <= px + radius; x++) {
            for (let z = pz - radius; z <= pz + radius; z++) {
                for (let y = py - 1; y <= py + 3; y++) {
                    const block = dim.getBlock({ x: x, y: y, z: z });
                    if (block && isWindowBlock(block.typeId)) {
                        const neighbors = [
                            { x: x + 1, y: y, z: z, dirX: 1, dirZ: 0 },
                            { x: x - 1, y: y, z: z, dirX: -1, dirZ: 0 },
                            { x: x, y: y, z: z + 1, dirX: 0, dirZ: 1 },
                            { x: x, y: y, z: z - 1, dirX: 0, dirZ: -1 }
                        ];

                        for (const n of neighbors) {
                            const nBlock = dim.getBlock({ x: n.x, y: n.y, z: n.z });
                            if (nBlock && nBlock.isAir) {
                                const distPlayerToWindow = Math.hypot(pLoc.x - (x + 0.5), pLoc.z - (z + 0.5));
                                const distPlayerToNeighbor = Math.hypot(pLoc.x - (n.x + 0.5), pLoc.z - (n.z + 0.5));

                                if (distPlayerToNeighbor > distPlayerToWindow) {
                                    const isTopWindow = (y >= py + 2);
                                    const spawnY = isTopWindow ? y - 0.1 : y - 0.6;

                                    candidateWindows.push({
                                        pos: { 
                                            x: n.x + 0.5 + (n.dirX * 0.25), 
                                            y: spawnY, 
                                            z: n.z + 0.5 + (n.dirZ * 0.25) 
                                        },
                                        windowPos: { x: x + 0.5, y: y + 0.5, z: z + 0.5 },
                                        isTop: isTopWindow
                                    });
                                }
                            }
                        }
                    }
                }
            }
        }

        if (candidateWindows.length > 0) {
            return candidateWindows[Math.floor(Math.random() * candidateWindows.length)];
        }
        return null;
    } catch (e) {
        return null;
    }
}

function isPlayerLookingAtStalker(player, stalker) {
    try {
        const pHead = player.getHeadLocation();
        const sLoc = stalker.location;
        const sEyeY = sLoc.y + 1.2;

        const dx = sLoc.x - pHead.x;
        const dy = sEyeY - pHead.y;
        const dz = sLoc.z - pHead.z;
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

        if (dist > 25) return false;

        const viewDir = player.getViewDirection();
        const dot = viewDir.x * (dx / dist) + viewDir.y * (dy / dist) + viewDir.z * (dz / dist);

        const ray = player.dimension.getBlockFromRay(pHead, { x: dx, y: dy, z: dz }, {
            maxDistance: dist,
            includePassableBlocks: false,
            includeLiquidBlocks: false
        });

        let lineOfSight = true;
        if (ray && ray.block) {
            if (!isWindowBlock(ray.block.typeId)) {
                lineOfSight = false;
            }
        }

        return dot > 0.65 && lineOfSight;
    } catch (e) {
        return false;
    }
}

function isPlayerLookingBehindAtStalker(player, stalker) {
    try {
        const pHead = player.getHeadLocation();
        const sLoc = stalker.location;
        const dx = sLoc.x - pHead.x;
        const dy = (sLoc.y + 1.2) - pHead.y;
        const dz = sLoc.z - pHead.z;
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

        const viewDir = player.getViewDirection();
        const dot = viewDir.x * (dx / dist) + viewDir.y * (dy / dist) + viewDir.z * (dz / dist);

        return dot > 0.5;
    } catch (e) {
        return false;
    }
}

function getShakingText(secondsLeft, isTop) {
    const prefixes = ["§c§l", "§4§l", "§c"];
    const randomPrefix = prefixes[Math.floor(Math.random() * prefixes.length)];
    return isTop ? `§cDONT GO OUTSIDE §w${secondsLeft}s` : `${randomPrefix}DONT GO OUTSIDE §w${secondsLeft}s`;
}

function moveChaserGround(stalker, player, speed) {
    try {
        const dim = stalker.dimension;
        const sLoc = stalker.location;
        const pLoc = player.location;

        const dx = pLoc.x - sLoc.x;
        const dz = pLoc.z - sLoc.z;
        const dist = Math.hypot(dx, dz);

        if (dist > 0.8) {
            const vx = (dx / dist) * speed;
            const vz = (dz / dist) * speed;

            let targetX = sLoc.x + vx;
            let targetZ = sLoc.z + vz;

            const frontX = Math.floor(targetX);
            const frontZ = Math.floor(targetZ);
            const currentFootY = Math.floor(sLoc.y);

            let wallHeight = 0;
            let isUnbreakableObstacle = false;

            for (let checkY = currentFootY; checkY <= currentFootY + 10; checkY++) {
                const b = dim.getBlock({ x: frontX, y: checkY, z: frontZ });
                if (b && !b.isAir && !b.isLiquid) {
                    if (isPassableGrass(b.typeId)) continue;
                    if (isBlockUnbreakable(b.typeId)) {
                        isUnbreakableObstacle = true;
                    }
                    wallHeight++;
                } else {
                    break;
                }
            }

            let newY = sLoc.y;

            if (isUnbreakableObstacle) {
                targetX = sLoc.x - vz * speed;
                targetZ = sLoc.z + vx * speed;
                newY = currentFootY;
            } else if (wallHeight === 1) {
                newY = currentFootY + 1;
            } else if (wallHeight >= 2) {
                for (let offsetY = 0; offsetY < wallHeight + 2; offsetY++) {
                    destroyObstacleBlock(dim, frontX, currentFootY + offsetY, frontZ);
                }
                newY = currentFootY;
            } else {
                let groundY = currentFootY;
                for (let checkY = currentFootY + 1; checkY >= currentFootY - 5; checkY--) {
                    const blockBelow = dim.getBlock({ x: frontX, y: checkY, z: frontZ });
                    if (blockBelow && !blockBelow.isAir && !blockBelow.isLiquid && !isPassableGrass(blockBelow.typeId)) {
                        groundY = checkY + 1;
                        break;
                    }
                }
                newY = groundY;
            }

            const yaw = (Math.atan2(dz, dx) * 180) / Math.PI - 90;
            stalker.teleport({ x: targetX, y: newY, z: targetZ }, { rotation: { x: 0, y: yaw } });
        }
    } catch (e) {}
}

function spawnWindowStalker(dimension, players) {
    if (STATE.windowStalkerActive && !hasActive(dimension, STALKER_ID)) {
        STATE.windowStalkerActive = false;
    }
    if (STATE.windowStalkerActive) return;
    if (gameTime() < STATE.windowStalkerCooldownUntil) return;
    if (hasActive(dimension, STALKER_ID)) return;

    for (const player of players) {
        if (player.getGameMode() !== GameMode.survival && player.getGameMode() !== GameMode.adventure) continue;
        
        const spawnChance = isDay() ? DAY_CHANCE : NIGHT_CHANCE;
        if (Math.random() > spawnChance) continue;

        const staging = findBehindPlayerSpot(dimension, player, 4, 8) ?? player.location;
        
        try {
            const entity = dimension.spawnEntity(STALKER_ID, staging);
            if (entity) {
                STATE.windowStalkerActive = true;
                face(entity, player);

                windowStalkerStates.set(entity.id, {
                    mode: "WINDOW_SEARCH",
                    windowPrepared: false,
                    windowSearchRadius: 16,
                    maxAge: 20 * 63,
                    appearDelay: 6,
                    knockTimer: 0,
                    spotted: false,
                    spottedTicks: 0,
                    targetPlayer: player,
                    behindSeen: false,
                    behindSeenTimer: 0,
                    chaseTimer: 0,
                    searchTicks: 0
                });
            }
            return;
        } catch (e) {}
    }
}

system.runInterval(() => {
    const overworld = world.getDimension("overworld");
    const players = Array.from(world.getPlayers());
    spawnWindowStalker(overworld, players);
}, 160);

world.afterEvents.entitySpawn.subscribe((event) => {
    const entity = event.entity;
    if (entity.typeId === STALKER_ID) {
        system.runTimeout(() => {
            if (!windowStalkerStates.has(entity.id)) {
                const players = Array.from(world.getPlayers());
                if (players.length > 0) {
                    const player = players[0];
                    STATE.windowStalkerActive = true;
                    face(entity, player);

                    windowStalkerStates.set(entity.id, {
                        mode: "WINDOW_SEARCH",
                        windowPrepared: false,
                        windowSearchRadius: 16,
                        maxAge: 20 * 63,
                        appearDelay: 6,
                        knockTimer: 0,
                        spotted: false,
                        spottedTicks: 0,
                        targetPlayer: player,
                        behindSeen: false,
                        behindSeenTimer: 0,
                        chaseTimer: 0,
                        searchTicks: 0
                    });
                } else {
                    try { entity.remove(); } catch (e) {}
                }
            }
        }, 2);
    }
});

// MAIN TICK LOOP
system.runInterval(() => {
    const overworld = world.getDimension("overworld");
    const stalkers = Array.from(overworld.getEntities({ type: STALKER_ID }));

    for (const stalker of stalkers) {
        if (!stalker.isValid()) continue;

        const data = windowStalkerStates.get(stalker.id);
        if (!data) continue;

        const player = data.targetPlayer;
        if (!player || !player.isValid()) {
            stalker.remove();
            windowStalkerStates.delete(stalker.id);
            STATE.windowStalkerActive = false;
            continue;
        }

        if (data.mode === "WINDOW_SEARCH") {
            data.searchTicks += 2;

            if (data.searchTicks >= data.appearDelay) {
                if (isPlayerInsideHouse(player)) {
                    const spawnData = findOutsideWindowPos(player);

                    if (spawnData) {
                        stalker.teleport(spawnData.pos);
                        stalker.triggerEvent(spawnData.isTop ? "event:set_top" : "event:set_bottom");
                        
                        player.runCommandAsync("playsound keepsmiling:window_knock @s");

                        data.mode = "STALKER";
                        data.windowPos = spawnData.windowPos;
                        data.isTop = spawnData.isTop;
                        data.windowPrepared = true;
                    } else {
                        stalker.remove();
                        windowStalkerStates.delete(stalker.id);
                        STATE.windowStalkerActive = false;
                        STATE.windowStalkerCooldownUntil = gameTime() + 1200;
                        continue;
                    }
                } else {
                    stalker.remove();
                    windowStalkerStates.delete(stalker.id);
                    STATE.windowStalkerActive = false;
                    STATE.windowStalkerCooldownUntil = gameTime() + 1200;
                    continue;
                }
            }
        }
        else if (data.mode === "STALKER") {
            const isInside = isPlayerInsideHouse(player);
            const pLoc = player.location;
            const wPos = data.windowPos || stalker.location;
            const distToWindow = Math.hypot(pLoc.x - wPos.x, pLoc.z - wPos.z);

            // TRANSISI KE MODE BEHIND HANYA JIKA PLAYER BENAR-BENAR KELUAR RUMAH & JAUH DARI JENDELA (> 8 BLOK)
            if (!isInside && distToWindow > 8) {
                try {
                    player.runCommandAsync("stopsound @s keepsmiling:window_knock");
                    player.runCommandAsync("stopsound @s keepsmiling:window_spotted");
                    player.runCommandAsync("stopsound @s keepsmiling:window_spotted1");
                    player.onScreenDisplay.setActionBar("");
                } catch (e) {}

                data.mode = "BEHIND";
                stalker.triggerEvent("event:set_behind");
                
                const vDir = player.getViewDirection();
                const bPos = {
                    x: player.location.x - vDir.x * 3,
                    y: player.location.y,
                    z: player.location.z - vDir.z * 3
                };
                stalker.teleport(bPos);
                player.runCommandAsync("playsound keepsmiling:windows_chase @s");
                continue;
            }

            if (!data.spotted) {
                data.knockTimer += 2;
                if (data.knockTimer >= 100) {
                    player.runCommandAsync("playsound keepsmiling:window_knock @s");
                    data.knockTimer = 0;
                }

                if (isPlayerLookingAtStalker(player, stalker)) {
                    data.spotted = true;
                    data.spottedTicks = 0;

                    player.runCommandAsync("playsound keepsmiling:window_spotted @s");
                    player.runCommandAsync("playsound keepsmiling:window_spotted1 @s");
                }
            } 
            else {
                data.spottedTicks += 2;
                const currentLoc = stalker.location;
                const moveOffset = data.isTop ? 0.04 : -0.04;
                stalker.teleport({ x: currentLoc.x, y: currentLoc.y + moveOffset, z: currentLoc.z });

                const progressRatio = data.spottedTicks / 240;
                const displaySeconds = Math.max(0, Math.ceil(10 * (1 - progressRatio)));
                player.onScreenDisplay.setActionBar(getShakingText(displaySeconds, data.isTop));

                if (data.spottedTicks >= 240) {
                    player.onScreenDisplay.setActionBar("");
                    windowStalkerStates.delete(stalker.id);
                    STATE.windowStalkerActive = false;
                    STATE.windowStalkerCooldownUntil = gameTime() + 2400;
                    try { stalker.remove(); } catch (e) {}
                    continue;
                }
            }
        }
        else if (data.mode === "BEHIND") {
            data.chaseTimer += 2;

            if (data.chaseTimer >= 880) {
                try {
                    player.runCommandAsync("stopsound @s keepsmiling:windows_chase");
                    player.runCommandAsync("stopsound @s keepsmiling:windows_seen");
                    player.removeEffect("darkness");
                } catch (e) {}

                windowStalkerStates.delete(stalker.id);
                STATE.windowStalkerActive = false;
                STATE.windowStalkerCooldownUntil = gameTime() + 2400;
                try { stalker.remove(); } catch (e) {}
                continue;
            }

            const lookingBehind = isPlayerLookingBehindAtStalker(player, stalker);

            if (!data.behindSeen && !lookingBehind) {
                const vDir = player.getViewDirection();
                const targetPos = {
                    x: player.location.x - vDir.x * 3,
                    y: player.location.y,
                    z: player.location.z - vDir.z * 3
                };
                stalker.teleport(targetPos);
            }
            else if (!data.behindSeen && lookingBehind) {
                data.behindSeen = true;
                data.behindSeenTimer = 0;

                player.runCommandAsync("playsound keepsmiling:windows_seen @s");
                try {
                    player.addEffect("darkness", 100, { amplifier: 0, showParticles: false });
                } catch (e) {}
            }
            else if (data.behindSeen) {
                data.behindSeenTimer += 2;

                if (data.behindSeenTimer <= 20) {
                    const pHead = player.getHeadLocation();
                    const sLoc = stalker.location;
                    const dx = pHead.x - sLoc.x;
                    const dz = pHead.z - sLoc.z;
                    const yaw = (Math.atan2(dz, dx) * 180) / Math.PI - 90;
                    stalker.teleport(sLoc, { rotation: { x: 0, y: yaw } });
                } else {
                    moveChaserGround(stalker, player, 0.45);
                }
            }
        }
    }
}, 2);

world.afterEvents.entityDie.subscribe((event) => {
    if (event.deadEntity.typeId === "minecraft:player") {
        const player = event.deadEntity;
        try {
            player.runCommandAsync("stopsound @s keepsmiling:window_knock");
            player.runCommandAsync("stopsound @s keepsmiling:window_spotted");
            player.runCommandAsync("stopsound @s keepsmiling:window_spotted1");
            player.runCommandAsync("stopsound @s keepsmiling:windows_chase");
            player.runCommandAsync("stopsound @s keepsmiling:windows_seen");
            player.onScreenDisplay.setActionBar("");
            player.removeEffect("darkness");
        } catch (e) {}

        const overworld = world.getDimension("overworld");
        const stalkers = Array.from(overworld.getEntities({ type: STALKER_ID }));
        for (const tormentor of stalkers) {
            tormentor.remove();
            windowStalkerStates.delete(tormentor.id);
        }
        STATE.windowStalkerActive = false;
    }
});