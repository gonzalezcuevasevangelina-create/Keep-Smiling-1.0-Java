import { world } from "@minecraft/server";

// DAFTAR LENGKAP SELURUH IDENTIFIER ENTITAS HOROR DI KEEP SMILING
export const HORROR_ENTITIES = [
    "keepsmiling:tormentor_door",
    "keepsmiling:tormentor",
    "keepsmiling:smiler",
    "keepsmiling:stalker",
    "keepsmiling:bipedal_door",
    "keepsmiling:window_stalker",
    "keepsmiling:door_stalker",
    "keepsmiling:stalk_window",
    "keepsmiling:stalker_miner",
    "keepsmiling:stare",
    "keepsmiling:luster"
];

let globalCooldownUntilDay = -1;

// 1. CEK APAKAH ADA SALAH SATU ENTITAS HOROR YANG SEDANG AKTIF DI DUNIA
export function isAnyHorrorEntityActive(dimension) {
    if (!dimension) return false;
    for (const entityId of HORROR_ENTITIES) {
        try {
            const active = Array.from(dimension.getEntities({ type: entityId }));
            if (active.length > 0) return true;
        } catch (e) {}
    }
    return false;
}

// 2. CEK APAKAH WORLD SEDANG DALAM MASA COOLDOWN GLOBAL
export function isGlobalSpawnAllowed() {
    const currentDay = Math.floor(world.getAbsoluteTime() / 24000);
    return currentDay >= globalCooldownUntilDay;
}

// 3. SETEL MASA TUNGGU ACAK (1 SAMPAI 3 HARI MINECRAFT) SETELAH ENTITAS DESPAWN
export function triggerGlobalCooldown(minDays = 1, maxDays = 3) {
    const currentDay = Math.floor(world.getAbsoluteTime() / 24000);
    const randomDelay = Math.floor(Math.random() * (maxDays - minDays + 1)) + minDays;
    globalCooldownUntilDay = currentDay + randomDelay;
}
