import { system, world, GameMode } from "@minecraft/server";

const TREE_STALKER_ID = "keepsmiling:bipedal_tree";
const treeStalkerData = new Map();

function isLogBlock(typeId) {
    if (!typeId) return false;
    const id = typeId.toLowerCase();
    return id.includes("log") || id.includes("wood") || id.includes("stem") || id.includes("hyphae");
}

function findNearestHighestTree(dimension, centerPos, radius = 20) {
    let bestTree = null;
    let maxTreeHeight = -1;
    let minDistance = Infinity;

    const startX = Math.floor(centerPos.x);
    const startY = Math.floor(centerPos.y);
    const startZ = Math.floor(centerPos.z);

    for (let x = -radius; x <= radius; x += 2) {
        for (let z = -radius; z <= radius; z += 2) {
            for (let y = -5; y <= 10; y++) {
                const checkX = startX + x;
                const checkY = startY + y;
                const checkZ = startZ + z;

                try {
                    const block = dimension.getBlock({ x: checkX, y: checkY, z: checkZ });
                    if (block && isLogBlock(block.typeId)) {
                        let height = 0;
                        let currentY = checkY;
                        while (currentY < checkY + 20) {
                            const bAbove = dimension.getBlock({ x: checkX, y: currentY, z: checkZ });
                            if (bAbove && isLogBlock(bAbove.typeId)) {
                                height++;
                                currentY++;
                            } else {
                                break;
                            }
                        }

                        const dist = Math.hypot(checkX - startX, checkZ - startZ);

                        if (height > maxTreeHeight || (height === maxTreeHeight && dist < minDistance)) {
                            maxTreeHeight = height;
                            minDistance = dist;
                            bestTree = { x: checkX + 0.5, y: checkY, z: checkZ + 0.5, height: height };
                        }
                    }
                } catch (e) {}
            }
        }
    }

    return bestTree;
}

// MENGHITUNG SUDUT ROTASI YAW MENUJU PLAYER (LOGIKA PNTMC)
function yawToward(fromX, fromZ, toX, toZ) {
    const dx = toX - fromX;
    const dz = toZ - fromZ;
    return (Math.atan2(-dx, dz) * 180) / Math.PI;
}

// FUNGSI MENGINTIP DARI BALIK POHON
function getSpotBehindTree(treePos, playerPos) {
    const dx = playerPos.x - treePos.x;
    const dz = playerPos.z - treePos.z;
    const dist = Math.hypot(dx, dz);

    if (dist < 0.1) return treePos;

    // Vektor normal dari pohon ke player
    const nx = dx / dist;
    const nz = dz / dist;

    // Vektor tegak lurus (geser ke samping luar pohon)
    const sideX = -nz * 0.65; 
    const sideZ = nx * 0.65;
    const backDist = -0.4; // Bersembunyi di balik batang kayu

    const targetX = treePos.x + (nx * backDist) + sideX;
    const targetZ = treePos.z + (nz * backDist) + sideZ;

    return { x: targetX, y: treePos.y, z: targetZ };
}

function hasDirectLineOfSight(player, entity) {
    try {
        const headLoc = player.getHeadLocation();
        const ePos = entity.location;
        ePos.y += 1.5;

        const dx = ePos.x - headLoc.x;
        const dy = ePos.y - headLoc.y;
        const dz = ePos.z - headLoc.z;
        const dist = Math.hypot(dx, dy, dz);

        const viewDir = player.getViewDirection();
        const dot = (dx * viewDir.x + dy * viewDir.y + dz * viewDir.z) / dist;

        if (dot < 0.5) return false;

        const rayResult = player.dimension.getBlockFromRay(headLoc, { x: dx, y: dy, z: dz }, {
            maxDistance: dist,
            includePassableBlocks: false
        });

        if (rayResult && rayResult.block) {
            return false;
        }

        return true;
    } catch (e) {
        return false;
    }
}

function playGlobalSound(player, soundName, volume = 1.0, pitch = 1.0) {
    try {
        player.runCommandAsync(`playsound ${soundName} @s`);
    } catch (e) {
        try {
            player.dimension.playSound(soundName, player.location, { volume: volume, pitch: pitch });
        } catch (err) {}
    }
}

system.runInterval(() => {
    const overworld = world.getDimension("overworld");
    const players = Array.from(world.getPlayers());

    if (players.length === 0) return;

    const treeStalkers = Array.from(overworld.getEntities({ type: TREE_STALKER_ID }));

    for (const stalker of treeStalkers) {
        if (!stalker.isValid()) continue;

        let targetPlayer = null;
        let minDist = Infinity;

        for (const player of players) {
            if (player.getGameMode() !== GameMode.survival && player.getGameMode() !== GameMode.adventure) continue;
            const dist = Math.hypot(player.location.x - stalker.location.x, player.location.z - stalker.location.z);
            if (dist < minDist) {
                minDist = dist;
                targetPlayer = player;
            }
        }

        if (!targetPlayer) continue;

        // INI BAGIAN INISIALISASI POHON TERDEKAT
        if (!treeStalkerData.has(stalker.id)) {
            const nearestTree = findNearestHighestTree(stalker.dimension, stalker.location, 20);

            if (!nearestTree) {
                try { stalker.remove(); } catch (e) {}
                continue;
            }

            playGlobalSound(targetPlayer, "keepsmiling:bipedal_tree_spawn", 1.0, 1.0);

            treeStalkerData.set(stalker.id, {
                initialized: true,
                treePos: nearestTree
            });
        }

        // UPDATE TELEPORT REALTIME SETIAP TICK (PERSIS SEPERTI PNTMC)
        const stalkerInfo = treeStalkerData.get(stalker.id);
        if (stalkerInfo && stalkerInfo.treePos) {
            const spot = getSpotBehindTree(stalkerInfo.treePos, targetPlayer.location);
            const yaw = yawToward(spot.x, spot.z, targetPlayer.location.x, targetPlayer.location.z);

            try {
                stalker.teleport(
                    { x: spot.x, y: spot.y, z: spot.z },
                    { dimension: stalker.dimension, rotation: { x: 0, y: yaw } }
                );
            } catch (e) {}
        }

        // DESPAWN KETIKA PLAYER MEMANDANG DENGAN JELAS
        if (minDist <= 30) {
            const isLooking = hasDirectLineOfSight(targetPlayer, stalker);

            if (isLooking) {
                treeStalkerData.delete(stalker.id);
                try {
                    stalker.remove();
                } catch (e) {}
            }
        }
    }
}, 1);

world.afterEvents.entityDie.subscribe((event) => {
    if (event.deadEntity.typeId === TREE_STALKER_ID) {
        treeStalkerData.delete(event.deadEntity.id);
    }
});
