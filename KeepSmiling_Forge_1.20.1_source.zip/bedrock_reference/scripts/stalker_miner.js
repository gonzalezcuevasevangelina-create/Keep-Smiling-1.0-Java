import { world, system, GameMode } from "@minecraft/server";

const STALKER_MINER_ID = "keepsmiling:stalker_miner";
const minerStates = new Map();

let nextAllowedDayToSpawn = -1;

// DETEKSI BLOK BATU UNTUK SPAWN DI CAVE
function isStoneBlock(typeId) {
    if (!typeId) return false;
    const id = typeId.toLowerCase();
    return (id.includes("stone") || id.includes("deepslate") || id.includes("granite") || 
            id.includes("diorite") || id.includes("andesite") || id.includes("tuff") || 
            id.includes("dripstone") || id.includes("calcite")) && 
           !id.includes("water") && !id.includes("lava");
}

// FUNGSI UNTUK MEMAKSA PANDANGAN MATA PLAYER TERKUNCI KE STALKER MINER
function lockPlayerCameraToMiner(player, miner) {
    try {
        const pHead = player.getHeadLocation();
        const mHead = { x: miner.location.x, y: miner.location.y + 1.2, z: miner.location.z };

        const dx = mHead.x - pHead.x;
        const dy = mHead.y - pHead.y;
        const dz = mHead.z - pHead.z;

        const distXZ = Math.hypot(dx, dz);
        const yaw = (Math.atan2(dz, dx) * 180) / Math.PI - 90;
        const pitch = (Math.atan2(-dy, distXZ) * 180) / Math.PI;

        player.setRotation({ x: pitch, y: yaw });
    } catch (e) {}
}

// LOGIKA RAYCAST / LINE OF SIGHT PLAYER KE STALKER MINER
function hasLineOfSight(player, miner) {
    try {
        const pHead = player.getHeadLocation();
        const mHead = { x: miner.location.x, y: miner.location.y + 1.2, z: miner.location.z };

        const rayResult = player.dimension.getBlockFromRay(pHead, {
            x: mHead.x - pHead.x,
            y: mHead.y - pHead.y,
            z: mHead.z - pHead.z
        }, {
            maxDistance: Math.hypot(mHead.x - pHead.x, mHead.y - pHead.y, mHead.z - pHead.z),
            includeLiquidBlocks: false,
            includePassableBlocks: false
        });

        if (rayResult && rayResult.block) {
            const b = rayResult.block.typeId.toLowerCase();
            const isTransparent = b.includes("glass") || b.includes("pane") || b.includes("fence") || b.includes("trapdoor") || b.includes("iron_bars");
            if (!isTransparent) return false;
        }
        return true;
    } catch (e) {
        return false;
    }
}

// DETEKSI PANDANGAN MATA PLAYER (MAX 40 BLOK)
function isPlayerLookingAtMiner(player, miner) {
    try {
        const pHead = player.getHeadLocation();
        const mLoc = miner.location;
        const dx = mLoc.x - pHead.x;
        const dy = (mLoc.y + 1.2) - pHead.y;
        const dz = mLoc.z - pHead.z;

        const dist = Math.hypot(dx, dy, dz);
        if (dist > 40) return false;

        if (!hasLineOfSight(player, miner)) return false;

        const vVec = player.getViewDirection();
        const norm = { x: dx / dist, y: dy / dist, z: dz / dist };
        const dot = vVec.x * norm.x + vVec.y * norm.y + vVec.z * norm.z;

        return dot > 0.40;
    } catch (e) {
        return false;
    }
}

// MEMERIKSA BANGUNAN / RUMAH
function isInsideBuilding(dimension, location) {
    let solidCeiling = 0;
    for (let y = 1; y <= 15; y++) {
        const b = dimension.getBlock({ x: Math.floor(location.x), y: Math.floor(location.y + y), z: Math.floor(location.z) });
        if (b && !b.isAir && !b.isLiquid) {
            solidCeiling++;
        }
    }
    return solidCeiling >= 2;
}

// MEMO-MINING BLOK (PERMUKAAN / RUMAH)
function digMiningArea(dimension, centerPos) {
    const cx = Math.floor(centerPos.x);
    const cy = Math.floor(centerPos.y);
    const cz = Math.floor(centerPos.z);

    for (let x = cx - 2; x <= cx + 2; x++) {
        for (let z = cz - 2; z <= cz + 2; z++) {
            for (let y = cy - 2; y <= cy + 2; y++) {
                try {
                    const block = dimension.getBlock({ x, y, z });
                    if (block && !block.isAir && !block.isLiquid) {
                        const id = block.typeId.toLowerCase();
                        if (!id.includes("bedrock") && !id.includes("barrier")) {
                            dimension.runCommandAsync(`setblock ${x} ${y} ${z} air replace`);
                        }
                    }
                } catch (e) {}
            }
        }
    }
}

// SPAWNER UTAMA STALKER MINER
system.runInterval(() => {
    const overworld = world.getDimension("overworld");
    const timeOfDay = world.getTimeOfDay();
    const currentDay = Math.floor(world.getAbsoluteTime() / 24000);

    if (currentDay < nextAllowedDayToSpawn) return;

    const players = Array.from(world.getPlayers());
    const existingMiners = Array.from(overworld.getEntities({ type: STALKER_MINER_ID }));

    if (players.length === 0 || existingMiners.length > 0) return;

    const isMorning = timeOfDay >= 0 && timeOfDay < 3000;
    const isDay = timeOfDay >= 3000 && timeOfDay < 9000;
    const isAfternoon = timeOfDay >= 9000 && timeOfDay < 12000;
    const isSunset = timeOfDay >= 12000 && timeOfDay < 13000;
    const isNight = timeOfDay >= 13000 && timeOfDay <= 23000;

    for (const player of players) {
        if (player.getGameMode() !== GameMode.survival && player.getGameMode() !== GameMode.adventure) continue;

        const pLoc = player.location;
        const headBlock = overworld.getBlock({ x: Math.floor(pLoc.x), y: Math.floor(pLoc.y + 1), z: Math.floor(pLoc.z) });
        const isUnderground = pLoc.y < 50 || (headBlock && headBlock.getSkyLightLevel && headBlock.getSkyLightLevel() === 0);
        const inHouse = isInsideBuilding(overworld, pLoc);

        let chance = 0.0;

        if (isUnderground) {
            chance = 0.85;
        } else if (inHouse) {
            chance = 0.60;
        } else {
            if (isMorning) chance = 0.05;
            else if (isDay) chance = 0.05;
            else if (isAfternoon) chance = 0.10;
            else if (isSunset) chance = 0.25;
            else if (isNight) chance = 0.40;
        }

        if (Math.random() > chance) continue;

        const angle = Math.random() * Math.PI * 2;
        const dist = 15 + Math.random() * 10;
        const spawnX = pLoc.x + Math.cos(angle) * dist;
        const spawnZ = pLoc.z + Math.sin(angle) * dist;
        let spawnY = pLoc.y;

        let finalSpawnPos = null;

        if (isUnderground) {
            for (let checkY = Math.floor(pLoc.y + 5); checkY >= Math.floor(pLoc.y - 5); checkY--) {
                const b = overworld.getBlock({ x: Math.floor(spawnX), y: checkY, z: Math.floor(spawnZ) });
                if (b && isStoneBlock(b.typeId)) {
                    finalSpawnPos = { x: spawnX, y: checkY + 1, z: spawnZ };
                    break;
                }
            }
        } else {
            finalSpawnPos = { x: spawnX, y: spawnY, z: spawnZ };
            digMiningArea(overworld, finalSpawnPos);
        }

        if (!finalSpawnPos) finalSpawnPos = { x: spawnX, y: spawnY, z: spawnZ };

        try {
            const miner = overworld.spawnEntity(STALKER_MINER_ID, finalSpawnPos);
            overworld.playSound("keepsmiling:stalker_mining", finalSpawnPos, { volume: 3.0 });

            minerStates.set(miner.id, {
                soundCooldown: 40,
                isDisappearing: false,
                lockPlayer: null,
                lockTicksRemaining: 0
            });

            nextAllowedDayToSpawn = currentDay + 1;
            break;
        } catch (e) {}
    }
}, 100);

// LOOP UTAMA AI & KAMERA STALKER MINER (1 TICK UNTUK HASIL KAMERA MULUS)
system.runInterval(() => {
    const overworld = world.getDimension("overworld");
    const miners = Array.from(overworld.getEntities({ type: STALKER_MINER_ID }));
    const players = Array.from(world.getPlayers());

    for (const miner of miners) {
        if (!miner.isValid()) continue;

        let data = minerStates.get(miner.id) || { soundCooldown: 40, isDisappearing: false, lockPlayer: null, lockTicksRemaining: 0 };

        // JIKA SEDANG EFKE LOCK KAMERA BYE
        if (data.isDisappearing) {
            if (data.lockPlayer && data.lockPlayer.isValid() && data.lockTicksRemaining > 0) {
                lockPlayerCameraToMiner(data.lockPlayer, miner);
                data.lockTicksRemaining--;
            }
            minerStates.set(miner.id, data);
            continue;
        }

        let targetPlayer = null;
        let minDist = Infinity;

        for (const player of players) {
            const d = Math.hypot(player.location.x - miner.location.x, player.location.z - miner.location.z);
            if (d < minDist) {
                minDist = d;
                targetPlayer = player;
            }
        }

        if (!targetPlayer) continue;

        const isSpotted = isPlayerLookingAtMiner(targetPlayer, miner);

        if (isSpotted) {
            data.isDisappearing = true;
            data.lockPlayer = targetPlayer;
            data.lockTicksRemaining = 14; // Selama durasi bye (14 ticks = ~0.7 detik)

            try {
                // Efek Slowness V (amplifier: 4) & Speed VII (amplifier: 6) durasi 14 ticks
                targetPlayer.addEffect("slowness", 14, { amplifier: 4, showParticles: false });
                targetPlayer.addEffect("speed", 14, { amplifier: 6, showParticles: false });

                miner.triggerEvent("set_bye_pose"); 
                miner.runCommandAsync("event entity @s set_bye_pose");
                
                overworld.playSound("keepsmiling:stalker_miner_bye", miner.location, { volume: 3.0 });
            } catch (e) {}

            system.runTimeout(() => {
                try {
                    if (targetPlayer && targetPlayer.isValid()) {
                        targetPlayer.removeEffect("slowness");
                        targetPlayer.removeEffect("speed");
                    }
                    if (miner.isValid()) miner.remove();
                } catch (e) {}
                minerStates.delete(miner.id);
            }, 14);

        } else {
            data.soundCooldown--;
            if (data.soundCooldown <= 0) {
                try {
                    overworld.playSound("keepsmiling:stalker_mining", miner.location, { volume: 3.0 });
                } catch (e) {}
                data.soundCooldown = 40;
            }
        }

        minerStates.set(miner.id, data);
    }
}, 1);
