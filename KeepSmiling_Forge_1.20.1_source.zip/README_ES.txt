KEEP SMILING — BASE DE PORT A JAVA 1.20.1 FORGE
================================================

Este ZIP es un PROYECTO FUENTE INICIAL, no un .jar terminado.

Incluye:
- Proyecto Gradle para Forge 1.20.1 (Java 17).
- Recursos originales del pack de recursos Bedrock copiados como referencia.
- JSON y scripts originales del behavior pack en bedrock_reference/ para reescribirlos.

IMPORTANTE:
Los archivos de geometría, animaciones, controladores y entidades de Bedrock NO son
compatibles directamente con Forge. Los scripts JavaScript usan la API de Bedrock y
no se ejecutan en Java Edition. Por eso, todavía hay que convertir:
1. Geometrías/animaciones a modelos Java (por ejemplo, con GeckoLib, si se decide usarlo).
2. Cada entidad y su IA a clases Java.
3. Los eventos de puertas, ventanas, jumpscares, aparición y recetas a código/JSON Java.
4. Sonidos y sus registros a sounds.json de Java.
5. Texturas/ítems y spawn eggs a assets y registros Java.

No afirmes que el addon está convertido por completo hasta completar esas partes y compilar
el mod. Para compilar: abre la carpeta en un entorno con Java 17 y Gradle, y ejecuta
gradlew build (en Android puede requerir un entorno compatible).
