import { world, system, GameMode } from "@minecraft/server";

const TORMENTOR_ID = "keepsmiling:tormentor_door";
const tormentorStates = new Map();

let spawnCooldown = 0;
let lastWorldDaySpawned = -1;

function isDoorBlock(typeId) {
    if (!typeId) return false;
    const lower = typeId.toLowerCase();
    return lower.includes("door") && !lower.includes("trapdoor");
}

function isGlassBlock(typeId) {
    if (!typeId) return false;
    const lower = typeId.toLowerCase();
    return lower.includes("glass") || lower.includes("pane");
}

// BUKA KEDUA PINTU BERHADAPAN SECARA OTOMATIS
function openDoubleDoors(dim, doorPositions) {
    for (const pos of doorPositions) {
        try {
            const bBottom = dim.getBlock(pos);
            if (bBottom && isDoorBlock(bBottom.typeId)) {
                bBottom.setPermutation(bBottom.permutation.withState("open_bit", true));
            }
            const bTop = dim.getBlock({ x: pos.x, y: pos.y + 1, z: pos.z });
            if (bTop && isDoorBlock(bTop.typeId)) {
                bTop.setPermutation(bTop.permutation.withState("open_bit", true));
            }
        } catch (e) {}
    }
}

// CARI 2 PINTU BERHADAPAN (POSISI Y PRESISI DI ATAS BLOK PIJAKAN PINTU)
function findDoubleDoorPos(player) {
    try {
        const dim = player.dimension;
        const pLoc = player.location;
        const px = Math.floor(pLoc.x);
        const py = Math.floor(pLoc.y);
        const pz = Math.floor(pLoc.z);

        const radius = 10;
        const doubleDoors = [];

        for (let x = px - radius; x <= px + radius; x++) {
            for (let z = pz - radius; z <= pz + radius; z++) {
                for (let y = py - 2; y <= py + 3; y++) {
                    const block = dim.getBlock({ x: x, y: y, z: z });
                    const blockBelow = dim.getBlock({ x: x, y: y - 1, z: z });
                    
                    // Pastikan yang terdeteksi adalah bagian bawah pintu (bukan bagian atas)
                    if (block && isDoorBlock(block.typeId) && blockBelow && !isDoorBlock(blockBelow.typeId)) {
                        const neighbors = [
                            { x: x + 1, y: y, z: z },
                            { x: x - 1, y: y, z: z },
                            { x: x, y: y, z: z + 1 },
                            { x: x, y: y, z: z - 1 }
                        ];

                        for (const n of neighbors) {
                            const neighborBlock = dim.getBlock({ x: n.x, y: n.y, z: n.z });
                            if (neighborBlock && isDoorBlock(neighborBlock.typeId)) {
                                const dx = (x + 0.5) - pLoc.x;
                                const dz = (z + 0.5) - pLoc.z;

                                let outsideDirX = Math.abs(dx) > Math.abs(dz) ? (dx > 0 ? 1 : -1) : 0;
                                let outsideDirZ = Math.abs(dx) <= Math.abs(dz) ? (dz > 0 ? 1 : -1) : 0;

                                const spawnX = (x + n.x + 1) / 2 + outsideDirX * 0.05;
                                const spawnZ = (z + n.z + 1) / 2 + outsideDirZ * 0.05;

                                const yaw = (Math.atan2(-outsideDirZ, -outsideDirX) * 180) / Math.PI - 90;

                                doubleDoors.push({
                                    spawnPos: { x: spawnX, y: y, z: spawnZ }, // Y dikunci tepat di alas lantai pintu
                                    rotation: { x: 0, y: yaw },
                                    doorBlocks: [
                                        { x: x, y: y, z: z },
                                        { x: n.x, y: n.y, z: n.z }
                                    ]
                                });
                                break;
                            }
                        }
                    }
                }
            }
        }

        if (doubleDoors.length > 0) {
            return doubleDoors[Math.floor(Math.random() * doubleDoors.length)];
        }
        return null;
    } catch (e) {
        return null;
    }
}

// CARI POSISI DI LUAR JENDELA KACA
function findOutsideWindowPos(player) {
    try {
        const dim = player.dimension;
        const pLoc = player.location;
        const px = Math.floor(pLoc.x);
        const py = Math.floor(pLoc.y);
        const pz = Math.floor(pLoc.z);

        const radius = 12;
        const candidateWindows = [];

        for (let x = px - radius; x <= px + radius; x++) {
            for (let z = pz - radius; z <= pz + radius; z++) {
                for (let y = py - 1; y <= py + 3; y++) {
                    const block = dim.getBlock({ x: x, y: y, z: z });
                    if (block && isGlassBlock(block.typeId)) {
                        const dx = (x + 0.5) - pLoc.x;
                        const dz = (z + 0.5) - pLoc.z;

                        const outsideX = x + 0.5 + (dx > 0 ? 0.55 : -0.55);
                        const outsideZ = z + 0.5 + (dz > 0 ? 0.55 : -0.55);

                        const yaw = (Math.atan2(-dz, -dx) * 180) / Math.PI - 90;

                        candidateWindows.push({
                            spawnPos: { x: outsideX, y: y + 0.1, z: outsideZ },
                            glassPos: { x: x, y: y, z: z },
                            rotation: { x: 0, y: yaw }
                        });
                    }
                }
            }
        }

        if (candidateWindows.length > 0) {
            return candidateWindows[Math.floor(Math.random() * candidateWindows.length)];
        }
        return null;
    } catch (e) {
        return null;
    }
}

function isPlayerLookingAtStalker(player, stalker) {
    try {
        const pHead = player.getHeadLocation();
        const sLoc = stalker.location;

        const dx = sLoc.x - pHead.x;
        const dy = (sLoc.y + 1.2) - pHead.y;
        const dz = sLoc.z - pHead.z;
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

        if (dist > 15) return false;

        const viewDir = player.getViewDirection();
        const dot = viewDir.x * (dx / dist) + viewDir.y * (dy / dist) + viewDir.z * (dz / dist);

        return dot > 0.55;
    } catch (e) {
        return false;
    }
}

// SYSTEM SPAWN NATURAL (1X PER HARI ACAK, JARANG)
system.runInterval(() => {
    const players = Array.from(world.getPlayers());
    if (players.length === 0) return;

    const overworld = world.getDimension("overworld");

    spawnCooldown++;
    if (spawnCooldown < 200) return;
    spawnCooldown = 0;

    const currentDay = Math.floor(world.getAbsoluteTime() / 24000);
    if (currentDay <= lastWorldDaySpawned) return;

    if (Math.random() > 0.25) return;

    for (const player of players) {
        if (player.getGameMode() !== GameMode.survival && player.getGameMode() !== GameMode.adventure) continue;

        const doorData = findDoubleDoorPos(player);
        if (doorData) {
            try {
                const tormentor = overworld.spawnEntity(TORMENTOR_ID, doorData.spawnPos);
                tormentor.setRotation(doorData.rotation);

                openDoubleDoors(overworld, doorData.doorBlocks);

                tormentorStates.set(tormentor.id, {
                    phase: "DOOR",
                    timer: 0,
                    targetPlayer: player,
                    sawTriggered: false,
                    runPlayed: false,
                    knockPlayed: false
                });

                lastWorldDaySpawned = currentDay;
                break;
            } catch (e) {}
        }
    }
}, 60);

// SPAWN MANUAL (EGG / SUMMON) -> LANGSUNG DESPAWN JIKA TIDAK ADA 2 PINTU BERHADAPAN
world.afterEvents.entitySpawn.subscribe((event) => {
    const entity = event.entity;
    if (entity.typeId === TORMENTOR_ID) {
        system.runTimeout(() => {
            if (!tormentorStates.has(entity.id)) {
                const players = Array.from(world.getPlayers());
                if (players.length > 0) {
                    const player = players[0];
                    const overworld = world.getDimension("overworld");
                    const doorData = findDoubleDoorPos(player);

                    if (doorData) {
                        entity.teleport(doorData.spawnPos, { rotation: doorData.rotation });
                        openDoubleDoors(overworld, doorData.doorBlocks);

                        tormentorStates.set(entity.id, {
                            phase: "DOOR",
                            timer: 0,
                            targetPlayer: player,
                            sawTriggered: false,
                            runPlayed: false,
                            knockPlayed: false
                        });
                    } else {
                        try { entity.remove(); } catch (e) {}
                    }
                } else {
                    try { entity.remove(); } catch (e) {}
                }
            }
        }, 2);
    }
});

// TICK LOOP UTAMA
system.runInterval(() => {
    const overworld = world.getDimension("overworld");
    const tormentors = Array.from(overworld.getEntities({ type: TORMENTOR_ID }));

    for (const tormentor of tormentors) {
        if (!tormentor.isValid()) continue;

        const data = tormentorStates.get(tormentor.id);
        if (!data) continue;

        const player = data.targetPlayer;
        if (!player || !player.isValid()) {
            tormentor.remove();
            tormentorStates.delete(tormentor.id);
            continue;
        }

        const dist = Math.hypot(player.location.x - tormentor.location.x, player.location.z - tormentor.location.z);

        // FASE 1: PINTU
        if (data.phase === "DOOR") {
            if (!data.sawTriggered && dist <= 10 && isPlayerLookingAtStalker(player, tormentor)) {
                data.sawTriggered = true;
                data.timer = 0;

                try {
                    player.addEffect("slowness", 120, { amplifier: 10, showParticles: false });
                    player.onScreenDisplay.setTitle("I FOUND YOU");
                    player.runCommandAsync("playsound keepsmiling:tormentorsaw @s");
                } catch (e) {}
            }

            if (data.sawTriggered) {
                data.timer += 1;

                if (data.timer >= 120) { // 6 Detik
                    if (!data.runPlayed) {
                        try {
                            player.removeEffect("slowness");
                            player.runCommandAsync("playsound keepsmiling:tormentor_run @s");
                        } catch (e) {}
                        data.runPlayed = true;
                    }

                    // CEK KEBERADAAN KACA: JIKA TIDAK ADA KACA, LANGSUNG SELESAI / DESPAWN
                    const windowCheck = findOutsideWindowPos(player);
                    if (!windowCheck) {
                        tormentor.remove();
                        tormentorStates.delete(tormentor.id);
                        continue;
                    }

                    try { tormentor.teleport({ x: tormentor.location.x, y: -64, z: tormentor.location.z }); } catch (e) {}
                    data.phase = "WINDOW_DELAY";
                    data.timer = 0;
                }
            }
        }
        // FASE 1.5: JEDA 9 DETIK (180 TICK)
        else if (data.phase === "WINDOW_DELAY") {
            data.timer += 1;

            if (data.timer >= 180) {
                const windowData = findOutsideWindowPos(player);
                if (windowData) {
                    tormentor.teleport(windowData.spawnPos, { rotation: windowData.rotation });
                    tormentor.triggerEvent("event:set_top");

                    data.phase = "WINDOW_WAIT";
                    data.timer = 0;
                    data.hitStep = 0;
                    data.hitInStep = 0;
                    data.lastHitTick = 0;
                    data.fastHitTimer = 0;
                    data.glassPos = windowData.glassPos;
                } else {
                    tormentor.remove();
                    tormentorStates.delete(tormentor.id);
                }
            }
        }
        // FASE 2: MENUNGGU DILIHAT DI JENDELA
        else if (data.phase === "WINDOW_WAIT") {
            if (!data.knockPlayed) {
                player.runCommandAsync("playsound keepsmiling:tormentor_window_knock @s");
                data.knockPlayed = true;
            }

            if (isPlayerLookingAtStalker(player, tormentor)) {
                try {
                    player.runCommandAsync("stopsound @s keepsmiling:tormentor_window_knock");
                } catch (e) {}

                data.phase = "WINDOW_HIT";
                data.timer = 0;
                data.lastHitTick = system.currentTick;
            }
        }
        // FASE 3: MEMUKUL KACA BERTAHAP (1s -> 0.6s -> 0.3s -> Detik 0 Klimaks 1 Detik)
        else if (data.phase === "WINDOW_HIT") {
            const currentTick = system.currentTick;
            const wt = currentTick - data.lastHitTick;

            let currentDelay = 20;
            if (data.hitStep === 0) currentDelay = 20;      // 1 detik
            else if (data.hitStep === 1) currentDelay = 12; // 0.6 detik
            else if (data.hitStep === 2) currentDelay = 6;  // 0.3 detik
            else if (data.hitStep >= 3) currentDelay = 2;   // 0s Klimaks

            const hitDuration = Math.max(1, Math.min(4, Math.floor(currentDelay / 2)));

            if (wt < hitDuration) {
                tormentor.triggerEvent("event:set_bottom");
            } else {
                tormentor.triggerEvent("event:set_top");
            }

            if (wt >= currentDelay) {
                data.lastHitTick = currentTick;
                data.hitInStep++;

                tormentor.triggerEvent("event:set_bottom");
                player.runCommandAsync("playsound keepsmiling:tormentor_hit_window @s");

                if (data.hitStep < 3 && data.hitInStep >= 4) {
                    data.hitInStep = 0;
                    data.hitStep++;
                }
            }

            // Tahap Klimaks (Hit Step 3) Berjalan Selama Tepat 1 Detik (20 Tick)
            if (data.hitStep >= 3) {
                data.fastHitTimer++;
            }

            // Kaca Pecah Tepat Setelah Klimaks 1 Detik Selesai
            if (data.hitStep >= 3 && data.fastHitTimer >= 20) {
                if (data.glassPos) {
                    try {
                        const glassBlock = overworld.getBlock(data.glassPos);
                        if (glassBlock && isGlassBlock(glassBlock.typeId)) {
                            glassBlock.setType("minecraft:air");
                            player.runCommandAsync("playsound random.glass @s");
                        }
                    } catch (e) {}
                }

                tormentor.remove();
                tormentorStates.delete(tormentor.id);

                try {
                    player.addEffect("blindness", 320, { amplifier: 1, showParticles: false }); // 16 detik
                    player.runCommandAsync("playsound keepsmiling:tormentor_scream @s");
                } catch (e) {}
            }
        }
    }
}, 1);

world.afterEvents.entityDie.subscribe((event) => {
    if (event.deadEntity.typeId === "minecraft:player") {
        const player = event.deadEntity;
        try {
            player.runCommandAsync("stopsound @s keepsmiling:tormentorsaw");
            player.runCommandAsync("stopsound @s keepsmiling:tormentor_run");
            player.runCommandAsync("stopsound @s keepsmiling:tormentor_window_knock");
            player.runCommandAsync("stopsound @s keepsmiling:tormentor_hit_window");
            player.removeEffect("slowness");
            player.removeEffect("blindness");
        } catch (e) {}

        const overworld = world.getDimension("overworld");
        const tormentors = Array.from(overworld.getEntities({ type: TORMENTOR_ID }));
        for (const tormentor of tormentors) {
            tormentor.remove();
            tormentorStates.delete(tormentor.id);
        }
    }
});
