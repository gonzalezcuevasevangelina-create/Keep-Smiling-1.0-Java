import { world, system, GameMode } from "@minecraft/server";

const INFLUENCE_ID = "keepsmiling:influence";
const influenceStates = new Map();

let lastWorldDaySpawned = -1;

function isDayTime() {
    const time = world.getTimeOfDay();
    return time >= 0 && time < 12000;
}

// DETEKSI PLAYER ADA DI DESA (MEMERIKSA STRUCTURE / BED / VILLAGER / DOOR)
function isPlayerInVillage(player) {
    try {
        const dim = player.dimension;
        const pLoc = player.location;
        const px = Math.floor(pLoc.x);
        const py = Math.floor(pLoc.y);
        const pz = Math.floor(pLoc.z);

        // Scan radius 24 blok mencari indikator Desa (Bed/Door/Bell)
        for (let x = px - 20; x <= px + 20; x += 4) {
            for (let z = pz - 20; z <= pz + 20; z += 4) {
                for (let y = py - 4; y <= py + 8; y += 2) {
                    const block = dim.getBlock({ x: x, y: y, z: z });
                    if (block) {
                        const type = block.typeId.toLowerCase();
                        if (type.includes("bed") || type.includes("bell") || type.includes("door")) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    } catch (e) {
        return false;
    }
}

// MENCARI POSISI SPAWN SURFACING 20 BLOK DARI PLAYER
function findSurfacePos20Blocks(player) {
    try {
        const dim = player.dimension;
        const pLoc = player.location;
        const angle = Math.random() * Math.PI * 2;
        const dist = 20;

        const targetX = Math.floor(pLoc.x + Math.cos(angle) * dist);
        const targetZ = Math.floor(pLoc.z + Math.sin(angle) * dist);

        // Cari Ketinggian Permukaan Paling Atas (Meskipun Player di Cave)
        for (let y = 319; y >= -64; y--) {
            const bCurr = dim.getBlock({ x: targetX, y: y, z: targetZ });
            const bBelow = dim.getBlock({ x: targetX, y: y - 1, z: targetZ });

            if (bBelow && !bBelow.isAir && bCurr && bCurr.isAir) {
                return { x: targetX + 0.5, y: y, z: targetZ + 0.5 };
            }
        }
        return null;
    } catch (e) {
        return null;
    }
}

function facePlayer(entity, player) {
    try {
        const eLoc = entity.location;
        const pLoc = player.location;

        const dx = pLoc.x - eLoc.x;
        const dz = pLoc.z - eLoc.z;
        const yaw = (Math.atan2(dz, dx) * 180) / Math.PI - 90;

        entity.setRotation({ x: 0, y: yaw });
    } catch (e) {}
}

// MENYALAKAN API DI RUMAH/KAYU SEKITAR DESA
function burnVillageStructures(dim, centerLoc) {
    try {
        const cx = Math.floor(centerLoc.x);
        const cy = Math.floor(centerLoc.y);
        const cz = Math.floor(centerLoc.z);

        for (let x = cx - 12; x <= cx + 12; x += 2) {
            for (let z = cz - 12; z <= cz + 12; z += 2) {
                for (let y = cy - 2; y <= cy + 8; y += 2) {
                    const b = dim.getBlock({ x: x, y: y, z: z });
                    if (b) {
                        const type = b.typeId.toLowerCase();
                        if (type.includes("log") || type.includes("planks") || type.includes("wood") || type.includes("leaves") || type.includes("fence")) {
                            const bAbove = dim.getBlock({ x: x, y: y + 1, z: z });
                            if (bAbove && bAbove.isAir) {
                                dim.runCommandAsync(`setblock ${x} ${y + 1} ${z} fire replace`);
                            }
                        }
                    }
                }
            }
        }
    } catch (e) {}
}

// SYSTEM SPAWN ALAMI (SETIAP 10 HARI MINECRAFT DI DESA & SIANG HARI)
system.runInterval(() => {
    const players = Array.from(world.getPlayers());
    if (players.length === 0) return;

    const overworld = world.getDimension("overworld");
    const existing = Array.from(overworld.getEntities({ type: INFLUENCE_ID }));
    if (existing.length >= 1) return;

    if (!isDayTime()) return;

    const currentDay = Math.floor(world.getAbsoluteTime() / 24000);
    if (lastWorldDaySpawned !== -1 && (currentDay - lastWorldDaySpawned) < 10) {
        return;
    }

    for (const player of players) {
        if (player.getGameMode() !== GameMode.survival && player.getGameMode() !== GameMode.adventure) continue;

        if (isPlayerInVillage(player)) {
            const spawnPos = findSurfacePos20Blocks(player);
            if (spawnPos) {
                try {
                    const influence = overworld.spawnEntity(INFLUENCE_ID, spawnPos);
                    lastWorldDaySpawned = currentDay;

                    influenceStates.set(influence.id, {
                        timer: 0,
                        targetPlayer: player,
                        msgState: 0
                    });

                    // MAINKAN AUDIO THE INFLUENCE & EFEK NAUSEA TANPA PARTIKEL
                    player.runCommandAsync("playsound keepsmiling:the_influence @s");
                    player.addEffect("nausea", 760, { amplifier: 1, showParticles: false });
                    break;
                } catch (e) {}
            }
        }
    }
}, 40);

// HANDLER SPAWN MANUAL (SPAWN EGG / SUMMON)
world.afterEvents.entitySpawn.subscribe((event) => {
    const entity = event.entity;
    if (entity.typeId === INFLUENCE_ID) {
        system.runTimeout(() => {
            if (!influenceStates.has(entity.id)) {
                const players = Array.from(world.getPlayers());
                if (players.length > 0) {
                    const player = players[0];
                    influenceStates.set(entity.id, {
                        timer: 0,
                        targetPlayer: player,
                        msgState: 0
                    });

                    player.runCommandAsync("playsound keepsmiling:the_influence @s");
                    player.addEffect("nausea", 760, { amplifier: 1, showParticles: false });
                }
            }
        }, 2);
    }
});

// MAIN TICK LOOP (1 TICK)
system.runInterval(() => {
    const overworld = world.getDimension("overworld");
    const influences = Array.from(overworld.getEntities({ type: INFLUENCE_ID }));

    for (const mob of influences) {
        if (!mob.isValid()) continue;

        const data = influenceStates.get(mob.id);
        if (!data) continue;

        const player = data.targetPlayer;
        if (!player || !player.isValid()) {
            cleanupInfluence(mob, data);
            continue;
        }

        facePlayer(mob, player);
        data.timer += 1;

        // SEQUENCING PESAN CHAT
        // 1. Pesan 1 (Detik 2 / 40 Ticks)
        if (data.timer === 40) {
            world.sendMessage("It's been a long time since I absorbed this energy");
        }
        // 2. Pesan 2 (Detik 5 / 100 Ticks)
        else if (data.timer === 100) {
            world.sendMessage("Now I will");
        }
        // 3. Pesan 3 (Detik 8 / 160 Ticks) -> MULAI KEBAKARAN
        else if (data.timer === 160) {
            world.sendMessage("§cDESTROY THIS PLACE");
        }

        // SAAT PERISTIWA KEBAKARAN AKTIF (SETELAH PESAN KETIGA)
        if (data.timer >= 160) {
            // Bakar struktur kayu disekitar setiap 20 ticks
            if (data.timer % 20 === 0) {
                burnVillageStructures(overworld, mob.location);
            }

            // Berikan 2 Damage ke semua entitas di desa secara berkala (setiap 30 ticks)
            if (data.timer % 30 === 0) {
                try {
                    const nearbyEntities = overworld.getEntities({
                        location: mob.location,
                        maxDistance: 35
                    });
                    for (const ent of nearbyEntities) {
                        if (ent.id !== mob.id && ent.isValid()) {
                            ent.applyDamage(2);
                        }
                    }
                } catch (e) {}
            }
        }

        // DETEKSI PLAYER ATAU ENTITY MENDEKATI INFLUENCE (KILLED IN AN INSTANT)
        try {
            const closeEntities = overworld.getEntities({
                location: mob.location,
                maxDistance: 3.5
            });

            for (const ent of closeEntities) {
                if (ent.id !== mob.id && ent.isValid()) {
                    ent.applyDamage(9999);
                }
            }
        } catch (e) {}

        // DESPAWN DI DETIK KE-38 (760 TICKS)
        if (data.timer >= 760) {
            cleanupInfluence(mob, data);
        }
    }
}, 1);

function cleanupInfluence(mob, data) {
    if (data && data.targetPlayer && data.targetPlayer.isValid()) {
        try {
            data.targetPlayer.runCommandAsync("stopsound @s keepsmiling:the_influence");
            data.targetPlayer.removeEffect("nausea");
        } catch (e) {}
    }

    if (mob && mob.isValid()) {
        try { mob.remove(); } catch (e) {}
    }

    if (mob) {
        influenceStates.delete(mob.id);
    }
}

// CLEANUP SAAT PLAYER MATI ATAU ENTITY TERBUNUH
world.afterEvents.entityDie.subscribe((event) => {
    const dead = event.deadEntity;

    if (dead.typeId === INFLUENCE_ID) {
        const data = influenceStates.get(dead.id);
        if (data) cleanupInfluence(dead, data);
    } else if (dead.typeId === "minecraft:player") {
        const player = dead;
        try {
            player.runCommandAsync("stopsound @s keepsmiling:the_influence");
            player.removeEffect("nausea");
        } catch (e) {}

        const overworld = world.getDimension("overworld");
        const influences = Array.from(overworld.getEntities({ type: INFLUENCE_ID }));

        for (const mob of influences) {
            const data = influenceStates.get(mob.id);
            cleanupInfluence(mob, data);
        }
    }
});
