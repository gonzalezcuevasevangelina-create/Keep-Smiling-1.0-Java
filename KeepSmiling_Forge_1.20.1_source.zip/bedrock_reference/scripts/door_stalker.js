import { world, system, GameMode } from "@minecraft/server";

const DOOR_STALKER_ID = "keepsmiling:door_stalker";
const doorStalkerStates = new Map();

let spawnCooldown = 0;
let lastWorldDaySpawned = -1;

function isDoorBlock(typeId) {
    if (!typeId) return false;
    const lower = typeId.toLowerCase();
    return lower.includes("door") && !lower.includes("trapdoor");
}

// DETEKSI POSISI PRESISI DI ATAS DEPAN PINTU LUAR RUMAH
function findOutsideDoorPos(player) {
    try {
        const dim = player.dimension;
        const pLoc = player.location;
        const px = Math.floor(pLoc.x);
        const py = Math.floor(pLoc.y);
        const pz = Math.floor(pLoc.z);

        const radius = 10;

        for (let x = px - radius; x <= px + radius; x++) {
            for (let z = pz - radius; z <= pz + radius; z++) {
                for (let y = py - 2; y <= py + 3; y++) {
                    const block = dim.getBlock({ x: x, y: y, z: z });
                    const blockBelow = dim.getBlock({ x: x, y: y - 1, z: z });

                    // Hanya ambil alas pintu (blok pintu bagian bawah)
                    if (block && isDoorBlock(block.typeId) && blockBelow && !isDoorBlock(blockBelow.typeId)) {
                        
                        const dx = (x + 0.5) - pLoc.x;
                        const dz = (z + 0.5) - pLoc.z;

                        let outX = 0;
                        let outZ = 0;
                        if (Math.abs(dx) >= Math.abs(dz)) {
                            outX = dx >= 0 ? 1 : -1;
                        } else {
                            outZ = dz >= 0 ? 1 : -1;
                        }

                        // Offset presisi: 0.65 blok di luar pintu & y + 2.05 (tepat di atas frame pintu 2 blok)
                        const spawnPos = {
                            x: x + 0.5 + outX * 0.65,
                            y: y + 2.05, 
                            z: z + 0.5 + outZ * 0.65
                        };

                        const yaw = (Math.atan2(-outZ, -outX) * 180) / Math.PI - 90;

                        return {
                            spawnPos: spawnPos,
                            targetY: spawnPos.y - 1.25, // Posisi mengintip turun ke bawah
                            rotation: { x: 0, y: yaw }
                        };
                    }
                }
            }
        }
        return null;
    } catch (e) {
        return null;
    }
}

function isPlayerLookingAtDoorOrStalker(player, stalker) {
    try {
        const pHead = player.getHeadLocation();
        const sLoc = stalker.location;

        const dx = sLoc.x - pHead.x;
        const dy = (sLoc.y + 1.0) - pHead.y;
        const dz = sLoc.z - pHead.z;
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

        if (dist > 25) return false;

        const viewDir = player.getViewDirection();
        const dot = viewDir.x * (dx / dist) + viewDir.y * (dy / dist) + viewDir.z * (dz / dist);

        return dot > 0.45;
    } catch (e) {
        return false;
    }
}

// 1. SYSTEM SPAWN ALAMI (OVERWORLD TICK)
system.runInterval(() => {
    const players = Array.from(world.getPlayers());
    if (players.length === 0) return;

    const overworld = world.getDimension("overworld");
    const existing = Array.from(overworld.getEntities({ type: DOOR_STALKER_ID }));

    if (existing.length >= 1) return;

    spawnCooldown++;
    if (spawnCooldown < 100) return;
    spawnCooldown = 0;

    const currentDay = Math.floor(world.getAbsoluteTime() / 24000);
    if (currentDay <= lastWorldDaySpawned) return;

    if (Math.random() > 0.40) return;

    for (const player of players) {
        if (player.getGameMode() !== GameMode.survival && player.getGameMode() !== GameMode.adventure) {
            continue;
        }

        const spawnData = findOutsideDoorPos(player);
        if (spawnData) {
            try {
                const stalker = overworld.spawnEntity(DOOR_STALKER_ID, spawnData.spawnPos);
                stalker.setRotation(spawnData.rotation);

                doorStalkerStates.set(stalker.id, {
                    state: "SPAWNED",
                    timer: 0,
                    initialY: spawnData.spawnPos.y,
                    targetY: spawnData.targetY,
                    targetPlayer: player,
                    rotation: spawnData.rotation
                });

                player.runCommandAsync("playsound keepsmiling:door_stalker_spawn @s");
                lastWorldDaySpawned = currentDay;
                break;
            } catch (e) {}
        }
    }
}, 40);

// 2. HANDLER SPAWN MANUAL (SPAWN EGG / SUMMON)
world.afterEvents.entitySpawn.subscribe((event) => {
    const entity = event.entity;
    if (entity.typeId === DOOR_STALKER_ID) {
        system.runTimeout(() => {
            if (!doorStalkerStates.has(entity.id)) {
                const players = Array.from(world.getPlayers());
                if (players.length > 0) {
                    const player = players[0];
                    const spawnData = findOutsideDoorPos(player);

                    if (spawnData) {
                        entity.teleport(spawnData.spawnPos, { rotation: spawnData.rotation });
                        doorStalkerStates.set(entity.id, {
                            state: "SPAWNED",
                            timer: 0,
                            initialY: spawnData.spawnPos.y,
                            targetY: spawnData.targetY,
                            targetPlayer: player,
                            rotation: spawnData.rotation
                        });
                        player.runCommandAsync("playsound keepsmiling:door_stalker_spawn @s");
                    }
                }
                // Catatan: entity.remove() sengaja dihilangkan agar mob tidak hilang jika ditaruh manual tanpa pintu
            }
        }, 2);
    }
});

// 3. MAIN TICK LOOP (ANIMASI PEEKING & DESPAWN SEAMLESS)
system.runInterval(() => {
    const overworld = world.getDimension("overworld");
    const stalkers = Array.from(overworld.getEntities({ type: DOOR_STALKER_ID }));

    for (const stalker of stalkers) {
        if (!stalker.isValid()) continue;

        const data = doorStalkerStates.get(stalker.id);
        if (!data) continue;

        const player = data.targetPlayer;
        if (!player || !player.isValid()) {
            stalker.remove();
            doorStalkerStates.delete(stalker.id);
            continue;
        }

        const sLoc = stalker.location;

        if (data.state === "SPAWNED") {
            data.timer += 2;

            const isLooking = isPlayerLookingAtDoorOrStalker(player, stalker);

            if (isLooking || data.timer >= 200) {
                data.state = "PEEKING";
                data.timer = 0;

                try {
                    player.runCommandAsync("stopsound @s keepsmiling:door_stalker_spawn");
                    player.runCommandAsync("playsound keepsmiling:door_stalker_peek @s");
                } catch (e) {}
            }
        }
        else if (data.state === "PEEKING") {
            data.timer += 2;

            // Turun dari atas pintu (mengintip ke bawah)
            if (sLoc.y > data.targetY) {
                stalker.teleport({ x: sLoc.x, y: Math.max(data.targetY, sLoc.y - 0.06), z: sLoc.z }, { rotation: data.rotation });
            }

            if (data.timer >= 40) {
                data.state = "DESPAWNING";
                data.timer = 0;
            }
        }
        else if (data.state === "DESPAWNING") {
            data.timer += 2;

            // Naik kembali ke atas plafon/pintu lalu despawn
            stalker.teleport({ x: sLoc.x, y: sLoc.y + 0.08, z: sLoc.z }, { rotation: data.rotation });

            if (data.timer >= 20 || sLoc.y >= data.initialY) {
                doorStalkerStates.delete(stalker.id);
                try { stalker.remove(); } catch (e) {}
            }
        }
    }
}, 2);

// 4. CLEANUP SAAT PLAYER MATI
world.afterEvents.entityDie.subscribe((event) => {
    if (event.deadEntity.typeId === "minecraft:player") {
        const player = event.deadEntity;
        try {
            player.runCommandAsync("stopsound @s keepsmiling:door_stalker_spawn");
            player.runCommandAsync("stopsound @s keepsmiling:door_stalker_peek");
        } catch (e) {}

        const overworld = world.getDimension("overworld");
        const stalkers = Array.from(overworld.getEntities({ type: DOOR_STALKER_ID }));
        for (const stalker of stalkers) {
            stalker.remove();
            doorStalkerStates.delete(stalker.id);
        }
    }
});
