import { world, system, GameMode } from "@minecraft/server";

const BIPEDAL_DOOR_ID = "keepsmiling:bipedal_door";
const HAND_RIGHT_ID = "keepsmiling:bipedal_hand";
const HAND_LEFT_ID = "keepsmiling:bipedal_hand1";

const bipedalStates = new Map();
let lastWorldDaySpawned = -1;

function isDoorBlock(typeId) {
    if (!typeId) return false;
    const lower = typeId.toLowerCase();
    return lower.includes("door") && !lower.includes("trapdoor");
}

function openDoubleDoors(dim, doorPositions) {
    for (const pos of doorPositions) {
        try {
            const bBottom = dim.getBlock(pos);
            if (bBottom && isDoorBlock(bBottom.typeId)) {
                bBottom.setPermutation(bBottom.permutation.withState("open_bit", true));
            }
            const bTop = dim.getBlock({ x: pos.x, y: pos.y + 1, z: pos.z });
            if (bTop && isDoorBlock(bTop.typeId)) {
                bTop.setPermutation(bTop.permutation.withState("open_bit", true));
            }
        } catch (e) {}
    }
}

// METODE PNTMC: HANYA MENGUBAH OFFSET TANGAN (DIST 1 BLOCK DAN OFFSET KELUAR/MASUK 1 BLOCK)
function calculateHandSpot(dim, doorBlock, insideDirX, insideDirZ, isRightHand) {
    const dx = doorBlock.x;
    const dy = doorBlock.y;
    const dz = doorBlock.z;

    const sideX = -insideDirZ;
    const sideZ = insideDirX;
    const sideMultiplier = isRightHand ? 1 : -1;

    // Scan blok dinding di samping pintu (jarak 1 blok murni)
    for (const dist of [1]) {
        const wx = dx + sideX * sideMultiplier * dist;
        const wz = dz + sideZ * sideMultiplier * dist;

        for (const oy of [0, 1]) {
            const wy = dy + oy;
            try {
                const b = dim.getBlock({ x: wx, y: wy, z: wz });
                const type = b?.typeId ?? "";
                if (b && !b.isAir && !type.includes("door") && !type.includes("glass")) {
                    const wallYaw = (Math.atan2(-insideDirX, insideDirZ) * 180) / Math.PI;
                    return {
                        pos: {
                            x: wx + 0.5 + insideDirX * 0.51,
                            y: isRightHand ? wy - 0.2 : wy + 0.1, // Tangan kanan agak ke bawah sedikit (~0.2b)
                            z: wz + 0.5 + insideDirZ * 0.51
                        },
                        yaw: wallYaw
                    };
                }
            } catch (e) {}
        }
    }

    // Fallback jika tidak ada dinding
    const wallYaw = (Math.atan2(-insideDirX, insideDirZ) * 180) / Math.PI;
    return {
        pos: {
            x: dx + 0.5 + sideX * sideMultiplier * 0.85 + insideDirX * 0.51,
            y: isRightHand ? dy - 0.2 : dy + 0.1,
            z: dz + 0.5 + sideZ * sideMultiplier * 0.85 + insideDirZ * 0.51
        },
        yaw: wallYaw
    };
}

function findDoubleDoorPos(player) {
    try {
        const dim = player.dimension;
        const pLoc = player.location;
        const px = Math.floor(pLoc.x);
        const py = Math.floor(pLoc.y);
        const pz = Math.floor(pLoc.z);

        const radius = 10;
        const doubleDoors = [];

        for (let x = px - radius; x <= px + radius; x++) {
            for (let z = pz - radius; z <= pz + radius; z++) {
                for (let y = py - 2; y <= py + 3; y++) {
                    const block = dim.getBlock({ x: x, y: y, z: z });
                    const blockBelow = dim.getBlock({ x: x, y: y - 1, z: z });
                    
                    if (block && isDoorBlock(block.typeId) && blockBelow && !isDoorBlock(blockBelow.typeId)) {
                        const neighbors = [
                            { x: x + 1, y: y, z: z },
                            { x: x - 1, y: y, z: z },
                            { x: x, y: y, z: z + 1 },
                            { x: x, y: y, z: z - 1 }
                        ];

                        for (const n of neighbors) {
                            const neighborBlock = dim.getBlock({ x: n.x, y: n.y, z: n.z });
                            if (neighborBlock && isDoorBlock(neighborBlock.typeId)) {
                                const dx = (x + 0.5) - pLoc.x;
                                const dz = (z + 0.5) - pLoc.z;

                                let outsideX = Math.abs(dx) >= Math.abs(dz) ? (dx > 0 ? 1 : -1) : 0;
                                let outsideZ = Math.abs(dx) < Math.abs(dz) ? (dz > 0 ? 1 : -1) : 0;
                                let insideX = -outsideX;
                                let insideZ = -outsideZ;

                                const centerX = (x + n.x + 1) / 2;
                                const centerZ = (z + n.z + 1) / 2;
                                const rightX = -outsideZ;
                                const rightZ = outsideX;

                                const doorYaw = (Math.atan2(-outsideZ, -outsideX) * 180) / Math.PI - 90;

                                const handRightData = calculateHandSpot(dim, { x, y, z }, insideX, insideZ, true);
                                const handLeftData = calculateHandSpot(dim, { x: n.x, y: n.y, z: n.z }, insideX, insideZ, false);

                                doubleDoors.push({
                                    headPos: { 
                                        x: centerX + outsideX * 0.15 - rightX * 0.2, 
                                        y: y + 0.5, 
                                        z: centerZ + outsideZ * 0.15 - rightZ * 0.2 
                                    },
                                    handRightData: handRightData,
                                    handLeftData: handLeftData,
                                    rotation: { x: 0, y: doorYaw },
                                    slideDir: { x: rightX, z: rightZ },
                                    doorBlocks: [
                                        { x: x, y: y, z: z },
                                        { x: n.x, y: n.y, z: n.z }
                                    ]
                                });
                                break;
                            }
                        }
                    }
                }
            }
        }

        if (doubleDoors.length > 0) {
            return doubleDoors[Math.floor(Math.random() * doubleDoors.length)];
        }
        return null;
    } catch (e) {
        return null;
    }
}

function isPlayerLookingAtBipedal(player, bipedal) {
    try {
        const pHead = player.getHeadLocation();
        const bLoc = bipedal.location;

        const dx = bLoc.x - pHead.x;
        const dy = (bLoc.y + 0.8) - pHead.y;
        const dz = bLoc.z - pHead.z;
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

        if (dist > 10) return false;

        const viewDir = player.getViewDirection();
        const dot = viewDir.x * (dx / dist) + viewDir.y * (dy / dist) + viewDir.z * (dz / dist);

        return dot > 0.45;
    } catch (e) {
        return false;
    }
}

function lockPlayerCameraToBipedal(player, bipedal) {
    try {
        const pHead = player.getHeadLocation();
        const bHead = { x: bipedal.location.x, y: bipedal.location.y + 0.5, z: bipedal.location.z };

        const dx = bHead.x - pHead.x;
        const dy = bHead.y - pHead.y;
        const dz = bHead.z - pHead.z;

        const distXZ = Math.hypot(dx, dz);
        const yaw = (Math.atan2(dz, dx) * 180) / Math.PI - 90;
        const pitch = (Math.atan2(-dy, distXZ) * 180) / Math.PI;

        player.setRotation({ x: pitch, y: yaw });
    } catch (e) {}
}

function spawnBipedalFamily(overworld, doorData, player) {
    const bipedal = overworld.spawnEntity(BIPEDAL_DOOR_ID, doorData.headPos);
    bipedal.setRotation(doorData.rotation);

    const handRight = overworld.spawnEntity(HAND_RIGHT_ID, doorData.handRightData.pos);
    handRight.setRotation({ x: 0, y: doorData.handRightData.yaw });

    const handLeft = overworld.spawnEntity(HAND_LEFT_ID, doorData.handLeftData.pos);
    handLeft.setRotation({ x: 0, y: doorData.handLeftData.yaw });

    openDoubleDoors(overworld, doorData.doorBlocks);

    player.runCommandAsync("playsound keepsmiling:door_open @s");

    bipedalStates.set(bipedal.id, {
        state: "WAITING",
        timer: 0,
        targetPlayer: player,
        handRight: handRight,
        handLeft: handLeft,
        rotation: doorData.rotation,
        slideDir: doorData.slideDir
    });
}

system.runInterval(() => {
    const players = Array.from(world.getPlayers());
    if (players.length === 0) return;

    const overworld = world.getDimension("overworld");
    const existing = Array.from(overworld.getEntities({ type: BIPEDAL_DOOR_ID }));
    if (existing.length >= 1) return;

    const currentDay = Math.floor(world.getAbsoluteTime() / 24000);
    if (currentDay <= lastWorldDaySpawned) return;

    if (Math.random() > 0.35) return;

    for (const player of players) {
        if (player.getGameMode() !== GameMode.survival && player.getGameMode() !== GameMode.adventure) continue;

        const doorData = findDoubleDoorPos(player);
        if (doorData) {
            try {
                spawnBipedalFamily(overworld, doorData, player);
                lastWorldDaySpawned = currentDay;
                break;
            } catch (e) {}
        }
    }
}, 80);

world.afterEvents.entitySpawn.subscribe((event) => {
    const entity = event.entity;
    if (entity.typeId === BIPEDAL_DOOR_ID) {
        system.runTimeout(() => {
            if (!bipedalStates.has(entity.id)) {
                const players = Array.from(world.getPlayers());
                if (players.length > 0) {
                    const player = players[0];
                    const overworld = world.getDimension("overworld");
                    const doorData = findDoubleDoorPos(player);

                    if (doorData) {
                        spawnBipedalFamily(overworld, doorData, player);
                        try { entity.remove(); } catch (e) {}
                    } else {
                        try { entity.remove(); } catch (e) {}
                    }
                } else {
                    try { entity.remove(); } catch (e) {}
                }
            }
        }, 2);
    }
});

system.runInterval(() => {
    const overworld = world.getDimension("overworld");
    const bipedals = Array.from(overworld.getEntities({ type: BIPEDAL_DOOR_ID }));

    for (const bipedal of bipedals) {
        if (!bipedal.isValid()) continue;

        const data = bipedalStates.get(bipedal.id);
        if (!data) continue;

        const player = data.targetPlayer;
        if (!player || !player.isValid()) {
            cleanupBipedal(bipedal, data);
            continue;
        }

        if (data.state === "WAITING") {
            const isLooking = isPlayerLookingAtBipedal(player, bipedal);

            if (isLooking) {
                data.state = "FROZEN";
                data.timer = 0;

                try {
                    player.runCommandAsync("playsound keepsmiling:bipedal_door_music @s");
                } catch (e) {}
            }
        }
        else if (data.state === "FROZEN") {
            data.timer += 1;

            try {
                player.addEffect("slowness", 5, { amplifier: 255, showParticles: false });
            } catch (e) {}

            lockPlayerCameraToBipedal(player, bipedal);

            if (data.timer >= 240) {
                data.state = "SLIDING";
                data.timer = 0;

                try { player.removeEffect("slowness"); } catch (e) {}

                try {
                    if (data.handRight && data.handRight.isValid()) data.handRight.remove();
                    if (data.handLeft && data.handLeft.isValid()) data.handLeft.remove();
                } catch (e) {}

                try {
                    player.runCommandAsync("playsound keepsmiling:bipedal_door_run @s");
                } catch (e) {}
            }
        }
        else if (data.state === "SLIDING") {
            data.timer += 1;

            const loc = bipedal.location;
            const newX = loc.x + data.slideDir.x * 0.025;
            const newZ = loc.z + data.slideDir.z * 0.025;

            bipedal.teleport({ x: newX, y: loc.y, z: newZ }, { rotation: data.rotation });

            if (data.timer >= 100) {
                cleanupBipedal(bipedal, data);
            }
        }
    }
}, 1);

function cleanupBipedal(bipedal, data) {
    try {
        if (data.handRight && data.handRight.isValid()) data.handRight.remove();
        if (data.handLeft && data.handLeft.isValid()) data.handLeft.remove();
        if (bipedal.isValid()) bipedal.remove();
    } catch (e) {}
    bipedalStates.delete(bipedal.id);
}

world.afterEvents.entityDie.subscribe((event) => {
    if (event.deadEntity.typeId === "minecraft:player") {
        const player = event.deadEntity;
        try {
            player.runCommandAsync("stopsound @s keepsmiling:bipedal_door_music");
            player.runCommandAsync("stopsound @s keepsmiling:bipedal_door_run");
            player.removeEffect("slowness");
        } catch (e) {}

        const overworld = world.getDimension("overworld");
        const bipedals = Array.from(overworld.getEntities({ type: BIPEDAL_DOOR_ID }));
        for (const bipedal of bipedals) {
            const data = bipedalStates.get(bipedal.id);
            if (data) cleanupBipedal(bipedal, data);
        }
    }
});
