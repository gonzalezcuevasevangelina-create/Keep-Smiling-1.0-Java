import { world, system, GameMode } from "@minecraft/server";

const STARE_ID = "keepsmiling:stare";
const UNBREAKABLE = [
    "minecraft:bedrock", "minecraft:reinforced_deepslate", 
    "minecraft:barrier", "minecraft:command_block"
];

const stareStates = new Map();
const playerCooldowns = new Map();
let nextAllowedDayToSpawn = -1;

function isNight() {
    const time = world.getTimeOfDay();
    return time >= 13000 && time <= 23000;
}

function duePlayer(player, key, cooldownTicks) {
    const current = world.getAbsoluteTime();
    const mapKey = `${player.id}_${key}`;
    const last = playerCooldowns.get(mapKey) || 0;
    if (current - last >= cooldownTicks) {
        playerCooldowns.set(mapKey, current);
        return true;
    }
    return false;
}

function hasActive(dimension, typeId) {
    try {
        return Array.from(dimension.getEntities({ type: typeId })).length > 0;
    } catch (e) {
        return false;
    }
}

function isCave(dimension, location) {
    try {
        const headBlock = dimension.getBlock({ x: Math.floor(location.x), y: Math.floor(location.y + 1), z: Math.floor(location.z) });
        return location.y < 50 || (headBlock && headBlock.getSkyLightLevel && headBlock.getSkyLightLevel() === 0);
    } catch (e) {
        return false;
    }
}

function nearTree(dimension, location, radius) {
    try {
        const px = Math.floor(location.x);
        const py = Math.floor(location.y);
        const pz = Math.floor(location.z);

        for (let x = px - radius; x <= px + radius; x += 3) {
            for (let z = pz - radius; z <= pz + radius; z += 3) {
                for (let y = py - 2; y <= py + 5; y += 2) {
                    const block = dimension.getBlock({ x: x, y: y, z: z });
                    if (block && (block.typeId.includes("log") || block.typeId.includes("leaves"))) {
                        return true;
                    }
                }
            }
        }
        return false;
    } catch (e) {
        return false;
    }
}

function findCaveSpot(dimension, pLoc, minDist, maxDist, maxChecks) {
    try {
        for (let i = 0; i < maxChecks; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = minDist + Math.random() * (maxDist - minDist);
            const spawnX = Math.floor(pLoc.x + Math.cos(angle) * dist);
            const spawnZ = Math.floor(pLoc.z + Math.sin(angle) * dist);
            const spawnY = Math.floor(pLoc.y);

            const bBelow = dimension.getBlock({ x: spawnX, y: spawnY - 1, z: spawnZ });
            const bCurr = dimension.getBlock({ x: spawnX, y: spawnY, z: spawnZ });
            const bAbove = dimension.getBlock({ x: spawnX, y: spawnY + 1, z: spawnZ });

            if (bBelow && !bBelow.isAir && bCurr && bCurr.isAir && bAbove && bAbove.isAir) {
                return { x: spawnX + 0.5, y: spawnY, z: spawnZ + 0.5 };
            }
        }
        return null;
    } catch (e) {
        return null;
    }
}

function findSurfaceSpot(dimension, pLoc, minDist, maxDist, maxChecks, filterFn) {
    try {
        for (let i = 0; i < maxChecks; i++) {
            const angle = Math.random() * Math.PI * 2;
            const dist = minDist + Math.random() * (maxDist - minDist);
            const spawnX = Math.floor(pLoc.x + Math.cos(angle) * dist);
            const spawnZ = Math.floor(pLoc.z + Math.sin(angle) * dist);
            const spawnY = Math.floor(pLoc.y);

            const spotPos = { x: spawnX + 0.5, y: spawnY, z: spawnZ + 0.5 };
            if (filterFn && !filterFn(spotPos)) continue;

            const bBelow = dimension.getBlock({ x: spawnX, y: spawnY - 1, z: spawnZ });
            const bCurr = dimension.getBlock({ x: spawnX, y: spawnY, z: spawnZ });

            if (bBelow && !bBelow.isAir && bCurr && bCurr.isAir) {
                return spotPos;
            }
        }
        return null;
    } catch (e) {
        return null;
    }
}

// LOGIKA MAYBE SPAWN STARE
function maybeSpawnStare(dimension, player) {
    if (!duePlayer(player, "stare", 20 * 60)) return;
    if (hasActive(dimension, STARE_ID)) return;

    const cave = isCave(dimension, player.location);
    const forestNight = isNight() && nearTree(dimension, player.location, 12);
    if (!cave && !forestNight) return;

    if (Math.random() > 0.48) return;

    const pos = cave
        ? findCaveSpot(dimension, player.location, 16, 28, 32)
        : findSurfaceSpot(dimension, player.location, 16, 28, 32, p => nearTree(dimension, p, 12));

    if (!pos) return;

    try {
        const entity = dimension.spawnEntity(STARE_ID, pos);
        if (entity) {
            stareStates.set(entity.id, {
                phase: "waiting",
                chaseTimer: 0,
                runSoundTimer: 0,
                targetId: player.id
            });
        }
    } catch (e) {}
}

function isBlockUnbreakable(typeId) {
    if (!typeId) return false;
    const id = typeId.toLowerCase();
    return UNBREAKABLE.some(unb => id === unb || id.includes("bedrock"));
}

function hasLineOfSight(player, stare) {
    try {
        const pHead = player.getHeadLocation();
        const sHead = { x: stare.location.x, y: stare.location.y + 1.5, z: stare.location.z };

        const rayResult = player.dimension.getBlockFromRay(pHead, {
            x: sHead.x - pHead.x, y: sHead.y - pHead.y, z: sHead.z - pHead.z
        }, {
            maxDistance: Math.hypot(sHead.x - pHead.x, sHead.y - pHead.y, sHead.z - pHead.z),
            includeLiquidBlocks: false, includePassableBlocks: false
        });

        if (rayResult && rayResult.block) {
            const b = rayResult.block.typeId.toLowerCase();
            const isTransparent = b.includes("glass") || b.includes("fence") || b.includes("door");
            if (!isTransparent) return false;
        }
        return true;
    } catch (e) { return false; }
}

function isPlayerLookingAtStare(player, stare) {
    try {
        const pHead = player.getHeadLocation();
        const sLoc = stare.location;
        const dx = sLoc.x - pHead.x;
        const dy = (sLoc.y + 1.5) - pHead.y;
        const dz = sLoc.z - pHead.z;
        const dist = Math.hypot(dx, dy, dz);

        if (dist > 30) return false;
        if (!hasLineOfSight(player, stare)) return false;

        const vVec = player.getViewDirection();
        const norm = { x: dx / dist, y: dy / dist, z: dz / dist };
        const dot = vVec.x * norm.x + vVec.y * norm.y + vVec.z * norm.z;

        return dot > 0.40;
    } catch (e) { return false; }
}

function stopAllStareEffects(player) {
    try {
        player.runCommandAsync("stopsound @s keepsmiling:stare_music");
        player.runCommandAsync("stopsound @s keepsmiling:stare_run");
        player.runCommandAsync("stopsound @s keepsmiling:stare_seen");
        player.removeEffect("darkness");
        player.onScreenDisplay.setActionBar("");
    } catch (e) {}
}

function moveChaser(stare, player, speed) {
    try {
        const dim = stare.dimension;
        const sLoc = stare.location;
        const pLoc = player.location;
        const dx = pLoc.x - sLoc.x;
        const dz = pLoc.z - sLoc.z;
        const dist = Math.hypot(dx, dz);

        if (dist > 0.8) {
            let vx = (dx / dist) * speed;
            let vz = (dz / dist) * speed;
            let targetX = sLoc.x + vx;
            let targetZ = sLoc.z + vz;
            const currentFootY = Math.floor(sLoc.y);

            let newY = sLoc.y;
            let groundY = currentFootY;
            for (let checkY = currentFootY + 1; checkY >= currentFootY - 5; checkY--) {
                const b = dim.getBlock({ x: Math.floor(targetX), y: checkY, z: Math.floor(targetZ) });
                if (b && !b.isAir) { groundY = checkY + 1; break; }
            }
            newY = groundY;
            stare.teleport({ x: targetX, y: newY, z: targetZ }, { dimension: dim });
        }
    } catch (e) {}
}

world.afterEvents.entityDie.subscribe((event) => {
    if (event.deadEntity && event.deadEntity.typeId === "minecraft:player") {
        stopAllStareEffects(event.deadEntity);
        const overworld = world.getDimension("overworld");
        const stares = Array.from(overworld.getEntities({ type: STARE_ID }));
        for (const stare of stares) {
            stare.remove();
            stareStates.delete(stare.id);
        }
    }
});

// INTERVAL SYSTEM UNTUK PANGGIL MAYBE SPAWN STARE
system.runInterval(() => {
    const overworld = world.getDimension("overworld");
    const players = Array.from(world.getPlayers());

    for (const player of players) {
        if (player.getGameMode() !== GameMode.survival && player.getGameMode() !== GameMode.adventure) continue;
        maybeSpawnStare(overworld, player);
    }
}, 100);

system.runInterval(() => {
    const overworld = world.getDimension("overworld");
    const stares = Array.from(overworld.getEntities({ type: STARE_ID }));
    const players = Array.from(world.getPlayers());

    for (const stare of stares) {
        if (!stare.isValid()) continue;
        const data = stareStates.get(stare.id);
        if (data && data.phase === "chase") {
            let target = players.find(p => p.id === data.targetId) || players[0];
            if (target) {
                moveChaser(stare, target, 0.88);
                
                const dist = Math.hypot(target.location.x - stare.location.x, target.location.z - stare.location.z);
                if (dist <= 1.5) {
                    target.applyDamage(12);
                }
            }
        }
    }
}, 1);

system.runInterval(() => {
    const overworld = world.getDimension("overworld");
    const stares = Array.from(overworld.getEntities({ type: STARE_ID }));
    const players = Array.from(world.getPlayers());

    for (const stare of stares) {
        if (!stare.isValid()) continue;
        let data = stareStates.get(stare.id);
        
        if (!data) {
            data = { phase: "waiting", chaseTimer: 0, runSoundTimer: 0, targetId: players[0]?.id };
            stareStates.set(stare.id, data);
        }

        let targetPlayer = players.find(p => p.id === data.targetId) || players[0];
        if (!targetPlayer) continue;

        const pBlock = targetPlayer.dimension.getBlock(targetPlayer.location);
        if (pBlock && pBlock.lightLevel > 9 && data.phase === "chase") {
            stopAllStareEffects(targetPlayer);
            stare.remove();
            stareStates.delete(stare.id);
            continue;
        }

        if (data.phase === "waiting") {
            const isSeen = isPlayerLookingAtStare(targetPlayer, stare);

            if (isSeen) {
                stare.triggerEvent("set_seen_pose");
                try { targetPlayer.runCommandAsync("playsound keepsmiling:stare_seen @s"); } catch (e) {}

                const isDespawnChance = Math.random() < 0.50;

                if (isDespawnChance) {
                    data.phase = "bye";
                    system.runTimeout(() => {
                        try { if (stare.isValid()) stare.remove(); } catch (e) {}
                        stareStates.delete(stare.id);
                    }, 20);
                } else {
                    data.phase = "chase";
                    data.chaseTimer = 0;
                    data.runSoundTimer = 0;
                    try { targetPlayer.runCommandAsync("playsound keepsmiling:stare_music @s"); } catch (e) {}
                }
            }
        } 
        else if (data.phase === "chase") {
            data.chaseTimer += 2;
            data.runSoundTimer += 2;

            if (data.chaseTimer >= 1800) {
                stopAllStareEffects(targetPlayer);
                stare.remove();
                stareStates.delete(stare.id);
                continue;
            }

            if (data.runSoundTimer >= 100) {
                try { targetPlayer.runCommandAsync("playsound keepsmiling:stare_run @s"); } catch (e) {}
                data.runSoundTimer = 0;
            }

            targetPlayer.onScreenDisplay.setActionBar("§bRUN TO THE LIGHT !");
            
            const isSurvival = targetPlayer.getGameMode() === GameMode.survival || targetPlayer.getGameMode() === GameMode.adventure;
            if (isSurvival) {
                targetPlayer.addEffect("darkness", 40, { amplifier: 0, showParticles: false });
            }
        }

        stareStates.set(stare.id, data);
    }
}, 2);
