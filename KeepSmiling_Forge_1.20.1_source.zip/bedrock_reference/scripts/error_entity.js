import { system, world, GameMode } from "@minecraft/server";

const ERROR_ENTITY_ID = "keepsmiling:error_entity";
const errorData = new Map();

let lastWorldDaySpawned = -1;
let daysToWaitNextSpawn = 0;
let spawnCountToday = 0; // Maksimal 2 kali spawn

const UNBREAKABLE = [
    "minecraft:bedrock", 
    "minecraft:reinforced_deepslate", 
    "minecraft:barrier", 
    "minecraft:command_block",
    "minecraft:repeating_command_block",
    "minecraft:chain_command_block"
];

function isBlockUnbreakable(typeId) {
    if (!typeId) return false;
    const id = typeId.toLowerCase();
    return UNBREAKABLE.some(unb => id === unb || id.includes("bedrock") || id.includes("reinforced_deepslate"));
}

function findSpawnSpot(dimension, player) {
    try {
        const pLoc = player.location;
        const vDir = player.getViewDirection();
        const dist = 30; // Jarak 30 block dari player
        
        const targetX = Math.floor(pLoc.x - vDir.x * dist);
        const targetZ = Math.floor(pLoc.z - vDir.z * dist);
        const spawnY = Math.floor(pLoc.y);

        for (let yOffset = 5; yOffset >= -5; yOffset--) {
            const checkY = spawnY + yOffset;
            const bBelow = dimension.getBlock({ x: targetX, y: checkY - 1, z: targetZ });
            const bCurr = dimension.getBlock({ x: targetX, y: checkY, z: targetZ });
            const bAbove = dimension.getBlock({ x: targetX, y: checkY + 1, z: targetZ });

            if (bBelow && !bBelow.isAir && bCurr && bCurr.isAir && bAbove && bAbove.isAir) {
                return { x: targetX + 0.5, y: checkY, z: targetZ + 0.5 };
            }
        }
        return { x: targetX + 0.5, y: spawnY, z: targetZ + 0.5 };
    } catch (e) {
        return null;
    }
}

// SISTEM MATEMATIKA ROTASI KEPALA & REBAH (DARI STALKER)
function faceTarget(errorEntity, player, isChasing = false) {
    try {
        const pHead = player.getHeadLocation();
        const pLoc = player.location;
        const eLoc = errorEntity.location;

        const dx = pHead.x - eLoc.x;
        const dy = pHead.y - (eLoc.y + 1.2);
        const dz = pHead.z - eLoc.z;

        const distXZ = Math.hypot(dx, dz);
        const yaw = (Math.atan2(dz, dx) * 180) / Math.PI - 90;

        let pitch = 0;
        if (distXZ < 0.01) {
            pitch = dy > 0 ? 89.9 : -89.9;
        } else {
            pitch = (Math.atan2(dy, distXZ) * 180) / Math.PI;
        }

        const yDiff = Math.abs(pLoc.y - eLoc.y);
        const isGroundLevel = yDiff <= 1.5;

        // Efek Rebah Saat Menyerang Dekat Player (< 6.5 block)
        if (isChasing && isGroundLevel && distXZ < 6.5) {
            const leanOffset = Math.sin((6.5 - distXZ) / 6.5 * (Math.PI / 2)) * 22.0;
            pitch -= leanOffset;
        }

        pitch = Math.max(-89.9, Math.min(89.9, pitch));
        errorEntity.setRotation({ x: pitch, y: yaw });
    } catch (e) {}
}

// MOVEMENT TELEPORTASI TERINSPIRASI DARI STALKER (SPEED 0.28 & LOMPAT 1 BLOCK)
function moveErrorEntity(errorEntity, player, speed = 0.28) {
    try {
        const dim = errorEntity.dimension;
        const eLoc = errorEntity.location;
        const pLoc = player.location;

        const dx = pLoc.x - eLoc.x;
        const dz = pLoc.z - eLoc.z;
        const dist = Math.hypot(dx, dz);

        if (dist > 0.8) {
            let vx = (dx / dist) * speed;
            let vz = (dz / dist) * speed;

            let targetX = eLoc.x + vx;
            let targetZ = eLoc.z + vz;

            const currentFootY = Math.floor(eLoc.y);
            let wallHeight = 0;
            let isUnbreakableObstacle = false;

            // Deteksi rintangan dinding di depan
            for (let checkY = currentFootY; checkY <= currentFootY + 10; checkY++) {
                const b = dim.getBlock({ x: Math.floor(targetX), y: checkY, z: Math.floor(targetZ) });
                if (b && !b.isAir) {
                    if (isBlockUnbreakable(b.typeId)) {
                        isUnbreakableObstacle = true;
                    }
                    wallHeight++;
                } else {
                    break;
                }
            }

            let newY = eLoc.y;

            if (isUnbreakableObstacle) {
                targetX = eLoc.x - vz * speed;
                targetZ = eLoc.z + vx * speed;
                newY = currentFootY;
            } 
            // MELOMPAT 1 BLOCK SEPERTI STALKER
            else if (wallHeight === 1) {
                newY = currentFootY + 1;
            } 
            // HANCURKAN BLOCK JIKA RINTANGAN >= 2 BLOCK (SAMPAI OBSIDIAN)
            else if (wallHeight >= 2) {
                for (let offsetY = 0; offsetY < wallHeight + 2; offsetY++) {
                    const checkY = currentFootY + offsetY;
                    try {
                        const blockToDestroy = dim.getBlock({ x: Math.floor(targetX), y: checkY, z: Math.floor(targetZ) });
                        if (blockToDestroy && !blockToDestroy.isAir) {
                            if (!isBlockUnbreakable(blockToDestroy.typeId)) {
                                dim.runCommandAsync(`setblock ${Math.floor(targetX)} ${checkY} ${Math.floor(targetZ)} air replace`);
                            }
                        }
                    } catch (e) {}
                }
                newY = currentFootY;
            } else {
                let groundY = currentFootY;
                for (let checkY = currentFootY + 1; checkY >= currentFootY - 5; checkY--) {
                    const blockBelow = dim.getBlock({ x: Math.floor(targetX), y: checkY, z: Math.floor(targetZ) });
                    if (blockBelow && !blockBelow.isAir) {
                        groundY = checkY + 1;
                        break;
                    }
                }
                newY = groundY;
            }

            errorEntity.teleport({ x: targetX, y: newY, z: targetZ }, { dimension: dim });
        }
        faceTarget(errorEntity, player, true);
    } catch (e) {}
}

// SYSTEM SPAWN ALAMI (BISA HARI APA SAJA, MAKS 2 KALI SPAWN SEBELUM COOLDOWN HARI)
system.runInterval(() => {
    const players = Array.from(world.getPlayers());
    if (players.length === 0) return;

    const overworld = world.getDimension("overworld");
    const existing = Array.from(overworld.getEntities({ type: ERROR_ENTITY_ID }));
    if (existing.length >= 1) return;

    const currentDay = Math.floor(world.getAbsoluteTime() / 24000);

    if (spawnCountToday >= 2) {
        if ((currentDay - lastWorldDaySpawned) < daysToWaitNextSpawn) {
            return;
        } else {
            spawnCountToday = 0;
        }
    }

    if (Math.random() > 0.40) return;

    for (const player of players) {
        if (player.getGameMode() !== GameMode.survival && player.getGameMode() !== GameMode.adventure) continue;

        const spawnPos = findSpawnSpot(overworld, player);
        if (spawnPos) {
            try {
                const errorMob = overworld.spawnEntity(ERROR_ENTITY_ID, spawnPos);
                
                try { errorMob.setProperty("minecraft:variant", 1); } catch(e) {}

                errorData.set(errorMob.id, {
                    state: "WAITING",
                    waitTimer: 0,
                    chaseTimer: 0,
                    targetPlayer: player
                });

                spawnCountToday++;
                if (spawnCountToday >= 2) {
                    lastWorldDaySpawned = currentDay;
                    daysToWaitNextSpawn = Math.floor(Math.random() * 3) + 1; // Cooldown 1-3 hari acak
                }
                break;
            } catch (e) {}
        }
    }
}, 40);

// HANDLER SPAWN MANUAL (SPAWN EGG / SUMMON)
world.afterEvents.entitySpawn.subscribe((event) => {
    const entity = event.entity;
    if (entity.typeId === ERROR_ENTITY_ID) {
        system.runTimeout(() => {
            if (!errorData.has(entity.id)) {
                const players = Array.from(world.getPlayers());
                if (players.length > 0) {
                    try { entity.setProperty("minecraft:variant", 1); } catch(e) {}
                    
                    errorData.set(entity.id, {
                        state: "WAITING",
                        waitTimer: 0,
                        chaseTimer: 0,
                        targetPlayer: players[0]
                    });
                }
            }
        }, 2);
    }
});

// TICK LOOP 1-TICK (GLITCH TIME & TELEPORT MOVEMENT SLOW-MO)
system.runInterval(() => {
    const overworld = world.getDimension("overworld");
    const errorEntities = Array.from(overworld.getEntities({ type: ERROR_ENTITY_ID }));

    for (const mob of errorEntities) {
        if (!mob.isValid()) continue;

        const data = errorData.get(mob.id);
        if (!data) continue;

        const player = data.targetPlayer;
        if (!player || !player.isValid()) continue;

        if (data.state === "WAITING") {
            faceTarget(mob, player, false);
        } else if (data.state === "CHASING") {
            moveErrorEntity(mob, player, 0.28);

            // GLITCH TIME WAKTU WORLD MC SELAMA 22 DETIK
            if (system.currentTick % 4 === 0) {
                const times = [0, 6000, 12000, 18000];
                const randomTime = times[Math.floor(Math.random() * times.length)];
                try { world.setTimeOfDay(randomTime); } catch (e) {}
            }
        }
    }
}, 1);

// TICK LOOP AI UTAMA ERROR ENTITY
system.runInterval(() => {
    const overworld = world.getDimension("overworld");
    const errorEntities = Array.from(overworld.getEntities({ type: ERROR_ENTITY_ID }));

    for (const mob of errorEntities) {
        if (!mob.isValid()) continue;

        const data = errorData.get(mob.id);
        if (!data) continue;

        const player = data.targetPlayer;
        if (!player || !player.isValid()) {
            cleanupErrorEntity(mob, data);
            continue;
        }

        const mLoc = mob.location;
        const pLoc = player.location;
        const dist = Math.hypot(pLoc.x - mLoc.x, pLoc.y - mLoc.y, pLoc.z - mLoc.z);

        if (data.state === "WAITING") {
            data.waitTimer += 2;

            // Player mendekat ke jarak <= 10 block -> MASUK MODE CHASE
            if (dist <= 10) {
                data.state = "CHASING";
                data.chaseTimer = 0;

                try {
                    player.runCommandAsync("playsound keepsmiling:error_entity_chase @s");
                } catch (e) {}
            }

            // Menunggu 2 menit (2400 Ticks) lalu Despawn
            if (data.waitTimer >= 2400) {
                cleanupErrorEntity(mob, data);
                continue;
            }
        } 
        else if (data.state === "CHASING") {
            data.chaseTimer += 2;

            // DESPAWN SELESAI PADA DETIK KE-22 (440 TICKS)
            if (data.chaseTimer >= 440) {
                cleanupErrorEntity(mob, data);
                continue;
            }
        }
    }
}, 2);

function cleanupErrorEntity(mob, data) {
    if (data && data.targetPlayer && data.targetPlayer.isValid()) {
        try {
            data.targetPlayer.runCommandAsync("stopsound @s keepsmiling:error_entity_chase");
        } catch (e) {}
    }
    
    if (mob && mob.isValid()) {
        try { mob.remove(); } catch (e) {}
    }
    
    if (mob) {
        errorData.delete(mob.id);
    }
}

// CLEANUP SAAT PLAYER MATI ATAU ERROR ENTITY TERBUNUH
world.afterEvents.entityDie.subscribe((event) => {
    const dead = event.deadEntity;

    if (dead.typeId === ERROR_ENTITY_ID) {
        const data = errorData.get(dead.id);
        if (data) cleanupErrorEntity(dead, data);
    } else if (dead.typeId === "minecraft:player") {
        const player = dead;
        try {
            player.runCommandAsync("stopsound @s keepsmiling:error_entity_chase");
            
            // Mengacak waktu sekali saat player mati
            const times = [0, 6000, 12000, 18000];
            const randomTime = times[Math.floor(Math.random() * times.length)];
            world.setTimeOfDay(randomTime);
        } catch (e) {}

        const overworld = world.getDimension("overworld");
        const errorEntities = Array.from(overworld.getEntities({ type: ERROR_ENTITY_ID }));

        for (const mob of errorEntities) {
            const data = errorData.get(mob.id);
            cleanupErrorEntity(mob, data);
        }
    }
});
