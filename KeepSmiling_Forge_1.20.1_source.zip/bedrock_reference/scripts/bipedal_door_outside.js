import { system, world, GameMode } from "@minecraft/server";

const SEE_OUTSIDE_ID = "keepsmiling:bipedal_see_outside";
const HAND_ID = "keepsmiling:bipedal_door_hand";
const outsideData = new Map();

function isDoorBlock(typeId) {
    if (!typeId) return false;
    const lower = typeId.toLowerCase();
    return lower.includes("door") && !lower.includes("trapdoor");
}

function isGlassOrFence(typeId) {
    if (!typeId) return false;
    const lower = typeId.toLowerCase();
    return lower.includes("glass") || lower.includes("pane") || lower.includes("fence");
}

// BUKA PINTU SECARA OTOMATIS SEPERTI DI BIPEDAL_DOOR.JS
function openDoubleDoors(dim, doorPositions) {
    for (const pos of doorPositions) {
        try {
            const bBottom = dim.getBlock(pos);
            if (bBottom && isDoorBlock(bBottom.typeId)) {
                bBottom.setPermutation(bBottom.permutation.withState("open_bit", true));
            }
            const bTop = dim.getBlock({ x: pos.x, y: pos.y + 1, z: pos.z });
            if (bTop && isDoorBlock(bTop.typeId)) {
                bTop.setPermutation(bTop.permutation.withState("open_bit", true));
            }
        } catch (e) {}
    }
}

// STRUKTUR PRESISI DETEKSI RUMAH & KOORDINAT
function analyzeHouseStructure(player, spawnLoc) {
    try {
        const dim = player.dimension;
        const pLoc = player.location;
        const px = Math.floor(pLoc.x);
        const py = Math.floor(pLoc.y);
        const pz = Math.floor(pLoc.z);

        const radius = 10;
        const doorBlocks = [];
        const windowBlocks = [];

        for (let x = px - radius; x <= px + radius; x++) {
            for (let z = pz - radius; z <= pz + radius; z++) {
                for (let y = py - 2; y <= py + 3; y++) {
                    const block = dim.getBlock({ x: x, y: y, z: z });
                    if (!block) continue;

                    if (isDoorBlock(block.typeId)) {
                        const bBelow = dim.getBlock({ x: x, y: y - 1, z: z });
                        if (bBelow && !isDoorBlock(bBelow.typeId)) {
                            doorBlocks.push({ x: x, y: y, z: z, block: block });
                        }
                    } else if (isGlassOrFence(block.typeId)) {
                        // Kaca/Pagar TIDAK BOLEH bertumpuk 2 block ke atas/bawah
                        const bAbove = dim.getBlock({ x: x, y: y + 1, z: z });
                        const bBelow = dim.getBlock({ x: x, y: y - 1, z: z });

                        if ((bAbove && isGlassOrFence(bAbove.typeId)) || (bBelow && isGlassOrFence(bBelow.typeId))) {
                            return null;
                        }

                        windowBlocks.push({ x: x, y: y, z: z });
                    }
                }
            }
        }

        // Harus ada minimal 2 pintu dan 1 blok kaca/pagar
        if (doorBlocks.length < 2 || windowBlocks.length === 0) {
            return null;
        }

        // Cari pasangan pintu berhadapan
        let pair = null;
        for (let i = 0; i < doorBlocks.length; i++) {
            for (let j = i + 1; j < doorBlocks.length; j++) {
                const d1 = doorBlocks[i];
                const d2 = doorBlocks[j];
                const dist = Math.hypot(d1.x - d2.x, d1.z - d2.z);
                if (dist >= 1.5 && dist <= 12) {
                    pair = { d1, d2 };
                    break;
                }
            }
            if (pair) break;
        }

        if (!pair) return null;

        const d1 = pair.d1;
        const d2 = pair.d2;

        // BACA ORIENTASI PINTU (facing_direction)
        let facingDir = 0;
        try {
            facingDir = d1.block.permutation.getState("facing_direction");
        } catch (e) {
            const dx = (d1.x + 0.5) - pLoc.x;
            const dz = (d1.z + 0.5) - pLoc.z;
            facingDir = Math.abs(dx) >= Math.abs(dz) ? (dx > 0 ? 1 : 3) : (dz > 0 ? 0 : 2);
        }

        let insideX = 0, insideZ = 0;
        if (facingDir === 0) { insideZ = 1; }       // South
        else if (facingDir === 1) { insideX = -1; }  // West
        else if (facingDir === 2) { insideZ = -1; }  // North
        else if (facingDir === 3) { insideX = 1; }   // East

        const outsideX = -insideX;
        const outsideZ = -insideZ;
        const sideX = -insideZ;
        const sideZ = insideX;

        // PILIH BLOK KACA/PAGAR TERDEKAT SESUAI ARAH/LOKASI SPAWN PLAYER
        let targetWindow = windowBlocks[0];
        let minWinDist = Infinity;

        for (const win of windowBlocks) {
            const dist = Math.hypot(win.x + 0.5 - spawnLoc.x, win.z + 0.5 - spawnLoc.z);
            if (dist < minWinDist) {
                minWinDist = dist;
                targetWindow = win;
            }
        }

        // Pastikan kaca tidak hanya ada di dinding samping (harus sejajar pintu)
        const wdx = targetWindow.x - d1.x;
        const wdz = targetWindow.z - d1.z;

        if (insideX !== 0 && Math.abs(wdx) < 1) return null;
        if (insideZ !== 0 && Math.abs(wdz) < 1) return null;

        const wallYaw = (Math.atan2(-insideX, insideZ) * 180) / Math.PI;

        return {
            headPos: {
                x: targetWindow.x + 0.5 + outsideX * 0.45,
                y: targetWindow.y,
                z: targetWindow.z + 0.5 + outsideZ * 0.45
            },
            handPos: {
                x: d1.x + 0.5 + insideX * 0.35 + sideX * 0.75,
                y: d1.y,
                z: d1.z + 0.5 + insideZ * 0.35 + sideZ * 0.75
            },
            yaw: wallYaw,
            doorBlocks: [d1, d2]
        };
    } catch (e) {
        return null;
    }
}

function playGlobalSound(player, soundName, volume = 1.0, pitch = 1.0) {
    try {
        player.runCommandAsync(`playsound ${soundName} @s`);
    } catch (e) {
        try {
            player.dimension.playSound(soundName, player.location, { volume: volume, pitch: pitch });
        } catch (err) {}
    }
}

function getShakingText(text) {
    return "§c" + text;
}

system.runInterval(() => {
    const overworld = world.getDimension("overworld");
    const players = Array.from(world.getPlayers());

    if (players.length === 0) return;

    const seeOutsideEntities = Array.from(overworld.getEntities({ type: SEE_OUTSIDE_ID }));

    for (const entity of seeOutsideEntities) {
        if (!entity.isValid()) continue;

        let targetPlayer = null;
        let minDist = Infinity;

        for (const player of players) {
            if (player.getGameMode() !== GameMode.survival && player.getGameMode() !== GameMode.adventure) continue;
            const dist = Math.hypot(player.location.x - entity.location.x, player.location.z - entity.location.z);
            if (dist < minDist) {
                minDist = dist;
                targetPlayer = player;
            }
        }

        if (!targetPlayer) continue;

        if (!outsideData.has(entity.id)) {
            const house = analyzeHouseStructure(targetPlayer, entity.location);

            if (!house) {
                try { entity.remove(); } catch (e) {}
                continue;
            }

            outsideData.set(entity.id, { active: false, timer: 0 });

            // Sembunyikan sementara selama 1 detik (20 ticks)
            try {
                entity.teleport({ x: entity.location.x, y: -100, z: entity.location.z }, { dimension: entity.dimension });
            } catch (e) {}

            system.runTimeout(() => {
                if (!entity.isValid()) return;

                try {
                    // Buka pintu otomatis
                    openDoubleDoors(entity.dimension, house.doorBlocks);

                    // Teleport Kepala di luar kaca terdekat sesuai titik spawn player
                    entity.teleport(house.headPos, { dimension: entity.dimension, rotation: { x: 0, y: house.yaw } });

                    // Spawn Tangan tepat di pintu yang terbuka
                    const handEntity = entity.dimension.spawnEntity(HAND_ID, house.handPos);
                    if (handEntity && handEntity.isValid()) {
                        handEntity.setRotation({ x: 0, y: house.yaw });
                    }

                    playGlobalSound(targetPlayer, "keepsmiling:bipedal_door_scream", 1.0, 1.0);

                    outsideData.set(entity.id, {
                        handEntity: handEntity,
                        timer: 0,
                        active: true
                    });
                } catch (e) {}
            }, 20);

            continue;
        }

        const data = outsideData.get(entity.id);
        if (!data || !data.active) continue;

        targetPlayer.onScreenDisplay.setActionBar(getShakingText("Dont near him..."));

        const distToEntity = Math.hypot(targetPlayer.location.x - entity.location.x, targetPlayer.location.z - entity.location.z);

        // Instant kill jika player mendekat <= 5 block
        if (distToEntity <= 5) {
            try {
                targetPlayer.applyDamage(1000);
            } catch (e) {}
        }

        // Despawn di detik ke-14 (280 Ticks)
        data.timer += 1;
        if (data.timer >= 280) {
            if (data.handEntity && data.handEntity.isValid()) {
                try { data.handEntity.remove(); } catch (e) {}
            }
            outsideData.delete(entity.id);
            try { entity.remove(); } catch (e) {}
        } else {
            outsideData.set(entity.id, data);
        }
    }
}, 1);

world.afterEvents.entityDie.subscribe((event) => {
    if (event.deadEntity.typeId === SEE_OUTSIDE_ID) {
        const data = outsideData.get(event.deadEntity.id);
        if (data && data.handEntity && data.handEntity.isValid()) {
            try { data.handEntity.remove(); } catch (e) {}
        }
        outsideData.delete(event.deadEntity.id);
    }
});
